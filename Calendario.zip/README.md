Añadidos dos botones en la esquina superior derecha:

- `Crear Aviso`: abre la URL de creación de avisos en Fiori (se abre en nueva pestaña).
- `Crear Permiso/CyMP`: abre la URL de creación de permisos en Fiori (se abre en nueva pestaña).

Prueba rápida:

1. Abrir `index.html` en un navegador moderno (copiar ruta local o usar un servidor local).
2. Los botones aparecen en la esquina superior derecha sobre el contenido.
3. Hacer clic en cada botón para abrir las URLs en una nueva pestaña (si estás en intranet, requerirás conexión/credenciales corporativas).

Notas:
- Los botones se posicionan con CSS absoluto relativo al contenedor principal.
- Si quieres que los botones estén en otra ubicación o dentro de un header, dime y lo muevo.
