// Configuración de Supabase
// Este fichero contiene las credenciales de acceso a la base de datos
const SUPABASE_URL = 'https://uifgjhpenpunkwrtrsjr.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVpZmdqaHBlbnB1bmt3cnRyc2pyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgyNzUwMTMsImV4cCI6MjA4Mzg1MTAxM30.C4DOHxSw15znI4KoQxwsMRISRovHPc6zfYvvYSsWW-Y';
