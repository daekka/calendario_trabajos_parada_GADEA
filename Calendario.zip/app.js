// Estado de la aplicación
let trabajos = []; // Array con todos los datos de trabajos
let trabajosConFechas = new Map(); // Map: fecha (string) -> array de índices de trabajos
let trabajosAsignados = new Set(); // Set de índices de trabajos que han sido asignados a alguna fecha
let trabajosModificados = new Set(); // Set de índices de trabajos cuya fecha ha sido modificada
let valoresOriginalesValidoDe = new Map(); // Map: índice -> valor original de "Válido de"
let horasTrabajos = new Map(); // Map: índice -> hora (string) para almacenar horas modificadas
let fechasFinTrabajos = new Map(); // Map: índice -> fecha fin (string) para almacenar fechas de finalización modificadas
let estadosPermisos = new Map(); // Map: índice -> estado (string) para almacenar estados de permisos: 'SOLICITADO', 'EJECUTADO', 'CERRADO'
// Map para almacenar aislamientos parseados desde fichero txt
// Estructura: { solicitudId: [ { numero: '3041727', descripcion: 'Fallo ...', estados: 'PREP NOBL NORO CERR' }, ... ] }
let aislamientosPorSolicitud = new Map();
// Map para almacenar solicitudes que empiezan por '4', agrupadas por Texto breve (normalizado)
let solicitudes4PorTexto = new Map(); // key: textoBreveNorm -> Array of solicitud strings starting with '4'
// Guardar última carga cruda (array de filas) para poder subir/recuperar exactamente el mismo formato
let ultimoJsonData = null;

// Nombres de columnas esperadas
const COLUMNAS_ESPERADAS = [
    'Orden', 'Solicitud', 'Tp.doc.descargo', 'Texto breve', 'Status de usuario',
    'Permisos', 'Documento', 'Texto explicativo', 'Interlocutor', 'Catálogo',
    'Creado por', 'Fecha de creación', 'Ubicación técnica', 'Equipo',
    'Texto explicativo', 'Válido de', 'Hora inicio validez', 'Validez a', 'Hora fin de validez',
    'Utilización'
];

// Configuración de Supabase (URL y KEY en config.js)
let supabaseClient = null;

// Inicializar cliente de Supabase
if (typeof window.supabase !== 'undefined' && window.supabase.createClient) {
    if (SUPABASE_URL.startsWith('http')) {
        try {
            supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
        } catch (e) {
            console.warn('Error inicializando Supabase, verifique credenciales', e);
        }
    } else {
        console.warn('Supabase URL no configurada, se omite inicialización.');
    }
}

// Helper: calcular CyMP para un trabajo (buscar solicitudes que empiezan por '4' por Texto breve)
function calcularCyMPParaTrabajo(indice) {
    const trabajo = trabajos[indice];
    if (!trabajo) return [];
    const textoBr = String(trabajo['Texto breve'] || '').replace(/^HGPIe:\s*/i, '').trim().toLowerCase();
    if (!textoBr) return [];
    const arr = solicitudes4PorTexto.get(textoBr);
    if (!arr || arr.length === 0) return [];
    // Devolver copia para evitar mutaciones
    return Array.from(arr);
}

// Referencias a elementos del DOM
const aislamientosContainer = document.getElementById('aislamientosContainer');
const filtroAislamientoInput = document.getElementById('filtroAislamientoInput');
const fileInput = document.getElementById('fileInput');
const fileTxtInput = document.getElementById('fileTxtInput');
const exportBtn = document.getElementById('exportBtn');
const exportBtnTop = document.getElementById('exportBtnTop');
const uploadSupabaseBtn = document.getElementById('uploadSupabaseBtn');
const readSupabaseBtn = document.getElementById('readSupabaseBtn');
const infoDatosNube = document.getElementById('infoDatosNube');
const trabajosList = document.getElementById('trabajosList');
const calendarioContainer = document.getElementById('calendarioContainer');
const fechaInicio = document.getElementById('fechaInicio');
const fechaFin = document.getElementById('fechaFin');
const actualizarCalendarioBtn = document.getElementById('actualizarCalendarioBtn');
// Referencias Dropdown
const dropdownBtn = document.getElementById('dropdownBtn');
const dropdownMenu = document.getElementById('dropdownMenu');
// Referencias Listado
const listadoContainer = document.getElementById('listadoContainer');
const listadoFechaInicio = document.getElementById('listadoFechaInicio');
const listadoFechaFin = document.getElementById('listadoFechaFin');
const actualizarListadoBtn = document.getElementById('actualizarListadoBtn');
const imprimirListadoBtn = document.getElementById('imprimirListadoBtn');

// NUEVO ESTADO GLOBAL
let filtroTipos = new Set(['TODOS']);

// Estado del filtro de texto
let filtroTextoActivo = true;
let filtroTextoValor = 'HGPI';

// Referencias filtro texto
const filtroTextoActivoCheckbox = document.getElementById('filtroTextoActivo');
const filtroTextoInput = document.getElementById('filtroTextoInput');

// Referencias para toggle de sección trabajos
const trabajosSection = document.getElementById('trabajosSection');
const trabajosContent = document.getElementById('trabajosContent');
const toggleTrabajosBtn = document.getElementById('toggleTrabajosBtn');

// Inicializar la sección 'trabajos' oculta al cargar la página
(function initTrabajosCollapsed() {
    if (!trabajosSection) return;

    // Añadir clase que controla el estado collapsed
    trabajosSection.classList.add('collapsed');

    // También marcar el contenido si existe (por seguridad)
    if (trabajosContent) {
        trabajosContent.classList.add('collapsed');
    }

    // Añadir clase al main para mantener el layout consistente
    const mainContentInit = document.querySelector('.main-content');
    if (mainContentInit) mainContentInit.classList.add('trabajos-collapsed');

    // Actualizar el texto y tooltip del botón toggle si existe
    if (toggleTrabajosBtn) {
        toggleTrabajosBtn.textContent = '▶';
        toggleTrabajosBtn.title = 'Mostrar trabajos';
        toggleTrabajosBtn.setAttribute('aria-expanded', 'false');
    }
})();

// Event listeners
fileInput.addEventListener('change', handleFileUpload);
if (fileTxtInput) fileTxtInput.addEventListener('change', handleTxtUpload);
exportBtn.addEventListener('click', exportarExcel);
if (exportBtnTop) exportBtnTop.addEventListener('click', exportarExcel);
if (uploadSupabaseBtn) uploadSupabaseBtn.addEventListener('click', subirDatosSupabase);
if (readSupabaseBtn) readSupabaseBtn.addEventListener('click', leerDatosSupabase);

// Event listeners para filtro de texto
if (filtroTextoActivoCheckbox) {
    filtroTextoActivoCheckbox.addEventListener('change', (e) => {
        filtroTextoActivo = e.target.checked;
        filtroTextoInput.disabled = !filtroTextoActivo;
        mostrarTrabajos();
    });
}
if (filtroTextoInput) {
    filtroTextoInput.addEventListener('input', (e) => {
        filtroTextoValor = e.target.value;
        mostrarTrabajos();
    });
}

// Event listener para toggle de sección trabajos
if (toggleTrabajosBtn) {
    const mainContent = document.querySelector('.main-content');
    toggleTrabajosBtn.addEventListener('click', () => {
        const isCollapsed = trabajosSection.classList.toggle('collapsed');
        mainContent.classList.toggle('trabajos-collapsed', isCollapsed);
        toggleTrabajosBtn.textContent = isCollapsed ? '▶' : '◀';
        toggleTrabajosBtn.title = isCollapsed ? 'Mostrar trabajos' : 'Ocultar trabajos';
    });
}

if (actualizarCalendarioBtn) {
    actualizarCalendarioBtn.addEventListener('click', actualizarCalendario);
}

// Debounce para resize
let resizeTimeout;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(igualarAnchoDias, 200);
});

// Lógica Dropdown y Filtros
if (dropdownBtn && dropdownMenu) {
    // Toggle dropdown
    dropdownBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdownMenu.classList.toggle('show');
    });

    // Cerrar al hacer click fuera
    document.addEventListener('click', (e) => {
        if (!dropdownBtn.contains(e.target) && !dropdownMenu.contains(e.target)) {
            dropdownMenu.classList.remove('show');
        }
    });

    // Función auxiliar para actualizar texto
    const actualizarTextoBoton = () => {
        if (filtroTipos.has('TODOS')) {
            dropdownBtn.textContent = 'TODOS';
        } else {
            const count = filtroTipos.size;
            if (count === 0) dropdownBtn.textContent = 'Seleccionar...';
            else if (count === 1) {
                const checked = dropdownMenu.querySelector('input[type="checkbox"]:checked');
                if(checked) dropdownBtn.textContent = checked.parentElement.textContent.trim();
            } else {
                dropdownBtn.textContent = `${count} seleccionados`;
            }
        }
    };

    // Manejar cambios en checkboxes
    dropdownMenu.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
            const value = e.target.value;
            const checked = e.target.checked;

            if (value === 'TODOS') {
                if (checked) {
                    // Si se marca TODOS, desmarcar el resto
                    dropdownMenu.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                        if (cb.value !== 'TODOS') cb.checked = false;
                    });
                    filtroTipos.clear();
                    filtroTipos.add('TODOS');
                } else {
                     // Si se desmarca TODOS manualmente y no hay otros, volver a marcar o dejar vacío
                     // Comportamiento: desmarcar TODOS sin marcar otro => vacío (0 resultados)
                     filtroTipos.delete('TODOS');
                }
            } else {
                // Si se marca uno específico
                if (checked) {
                    filtroTipos.add(value);
                    // Desmarcar TODOS si estaba
                    const todosCh = dropdownMenu.querySelector('input[value="TODOS"]');
                    if (todosCh.checked) {
                         todosCh.checked = false;
                         filtroTipos.delete('TODOS');
                    }
                } else {
                    filtroTipos.delete(value);
                    // Si nos quedamos vacíos, ¿volvemos a TODOS?
                    // Dejemos que el usuario decida. Si todo desmarcado -> muestra 0.
                    if (filtroTipos.size === 0) {
                        const todosCh = dropdownMenu.querySelector('input[value="TODOS"]');
                        todosCh.checked = true;
                        filtroTipos.add('TODOS');
                    }
                }
            }
            
            actualizarTextoBoton();
            actualizarCalendario();
        });
    });
}

// Manejar cambio de pestañas
document.querySelectorAll('.tab-button').forEach(button => {
    button.addEventListener('click', () => {
        const tabName = button.dataset.tab;
        
        // Remover clase active de todos los botones y contenidos
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        
        // Añadir clase active al botón y contenido seleccionado
        button.classList.add('active');
        document.getElementById(`${tabName}Tab`).classList.add('active');
        
        // Si se cambia a la pestaña Listado, generar el listado
        if (tabName === 'listado') {
            generarListado();
        }
        // Si se cambia a la pestaña Aislamientos, generar el listado de aislamientos
        if (tabName === 'aislamientos') {
            renderizarAislamientos();
        }
    // Renderizar listado de aislamientos con solicitudes asociadas (formato árbol)
    function renderizarAislamientos() {
        if (!aislamientosContainer) return;
        // Si no hay datos cargados
        if (!aislamientosPorSolicitud || aislamientosPorSolicitud.size === 0) {
            aislamientosContainer.innerHTML = '<p class="empty-message">No hay aislamientos cargados</p>';
            return;
        }
        // Obtener filtro
        const filtro = filtroAislamientoInput ? filtroAislamientoInput.value.trim() : '';
        // Map: numero aislamiento -> { descripcion, estados, solicitudes: [id, ...] }
        const aislamientosMap = new Map();
        // Recorrer todas las solicitudes y sus aislamientos
        for (const [solicitud, aislamientosArr] of aislamientosPorSolicitud.entries()) {
            for (const a of aislamientosArr) {
                if (!aislamientosMap.has(a.numero)) {
                    aislamientosMap.set(a.numero, {
                        descripcion: a.descripcion,
                        estados: a.estados,
                        solicitudes: []
                    });
                }
                aislamientosMap.get(a.numero).solicitudes.push(solicitud);
            }
        }
        // Filtrar por número si hay filtro
        let aislamientosFiltrados = Array.from(aislamientosMap.entries());
        if (filtro) {
            aislamientosFiltrados = aislamientosFiltrados.filter(([numero]) => numero.includes(filtro));
        }
        if (aislamientosFiltrados.length === 0) {
            aislamientosContainer.innerHTML = '<p class="empty-message">No hay aislamientos que coincidan</p>';
            return;
        }
        let html = '';
        for (const [numero, data] of aislamientosFiltrados) {
            html += `<div class="aislamiento-item">`;
            html += `<span class="aislamiento-numero">${numero}</span> <span class="aislamiento-descripcion">${data.descripcion}</span> <span class="aislamiento-estados">${data.estados}</span>`;
            html += `<div class="aislamiento-solicitudes">`;
            html += `<ul>`;
            for (const solicitud of data.solicitudes) {
                // Buscar trabajo asociado a la solicitud
                let textoBreve = '';
                let estado = '';
                for (const t of trabajos) {
                    if (t && t['Solicitud'] && t['Solicitud'].toString().trim() === solicitud) {
                        textoBreve = t['Texto breve'] || '';
                        // Buscar estado del permiso si existe
                        const idx = trabajos.indexOf(t);
                        estado = estadosPermisos.get(idx) || '';
                        break;
                    }
                }
                html += `<li class="aislamiento-solicitud-item"><b>${solicitud}</b>`;
                if (textoBreve) html += ` — <span class="aislamiento-solicitud-txt">${textoBreve}</span>`;
                if (estado) {
                    let badgeClass = 'badge-estado';
                    if (estado === 'AUTORIZADO') badgeClass += ' badge-autorizado';
                    else if (estado === 'APROBADO') badgeClass += ' badge-aprobado';
                    else if (estado === 'PENDIENTE') badgeClass += ' badge-pendiente';
                    else badgeClass += ' badge-otro';
                    html += ` <span class="${badgeClass}">${estado}</span>`;
                }
                html += `</li>`;
            }
            html += `</ul>`;
            html += `</div>`;
            html += `</div>`;
        }
        aislamientosContainer.innerHTML = html;
    }
// Renderizar aislamientos al cargar si ya hay datos
window.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('aislamientosTab')) {
        renderizarAislamientos();
    }
});

// Si cargas aislamientos desde fichero, llama a renderizarAislamientos() después de cargar los datos

    // Filtro de aislamientos por número
    if (filtroAislamientoInput) {
        filtroAislamientoInput.addEventListener('input', () => {
            renderizarAislamientos();
        });
    }
    });
});

// Event listeners para Listado
if (actualizarListadoBtn) {
    actualizarListadoBtn.addEventListener('click', generarListado);
}
if (imprimirListadoBtn) {
    imprimirListadoBtn.addEventListener('click', imprimirListado);
}

// Función para manejar la carga del archivo Excel
function handleFileUpload(event) {
    if (typeof XLSX === 'undefined') {
        alert('Error crítica: La librería SheetJS no está cargada. Revise la conexión a internet o el archivo index.html');
        return;
    }

    const file = event.target.files[0];
    if (!file) return;

    // Ocultar info de nube si subimos archivo local
    if (infoDatosNube) {
        infoDatosNube.style.display = 'none';
        infoDatosNube.textContent = '';
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = new Uint8Array(e.target.result);
            // Leer Excel SIN convertir fechas (raw numbers) para manejar seriales de Excel manualmente
            const workbook = XLSX.read(data, { type: 'array', cellDates: false });
            
            // Leer la primera hoja
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            
            // Convertir a JSON manteniendo valores raw (números seriales de Excel para fechas)
            const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, raw: true, defval: '' });
            
            if (jsonData.length < 2) {
                alert('El archivo Excel está vacío o no tiene datos válidos');
                return;
            }

            // La primera fila son los encabezados
            const headers = jsonData[0];
            
            // DEBUG: Mostrar headers y primeras filas para depuración
            console.log('=== DEPURACIÓN EXCEL ===');
            console.log('Headers encontrados:', headers);
            console.log('Número de filas:', jsonData.length);
            if (jsonData.length > 1) {
                console.log('Primera fila de datos:', jsonData[1]);
            }
            if (jsonData.length > 2) {
                console.log('Segunda fila de datos:', jsonData[2]);
            }
            
            // Validar que las columnas coincidan (aproximadamente)
            if (!validarColumnas(headers)) {
                alert('Las columnas del archivo no coinciden con el formato esperado');
                return;
            }

            // Guardar la carga cruda para poder subirla a la nube tal cual
            ultimoJsonData = jsonData;
            // Procesar los datos
            procesarDatos(jsonData);
            
            // Distribuir trabajos según fechas de parada
            distribuirTrabajos();
            
            // (Gantt eliminado)
            
            // Actualizar estadísticas
            actualizarEstadisticasTrabajos();
            
            // Habilitar botón de exportar (sidebar y top)
            exportBtn.disabled = false;
            if (exportBtnTop) exportBtnTop.disabled = false;
            
        } catch (error) {
            console.error('Error al leer el archivo:', error);
            alert('Error al leer el archivo Excel: ' + error.message);
        }
    };
    
    reader.readAsArrayBuffer(file);
}

// Validar que las columnas sean correctas
function validarColumnas(headers) {
    // Comparar las primeras columnas importantes
    const columnasImportantes = ['Orden', 'Solicitud', 'Texto breve'];
    return columnasImportantes.every(col => 
        headers.some(h => h && h.toString().trim() === col)
    );
}

// Procesar los datos del Excel
function procesarDatos(jsonData) {
    trabajos = [];
    trabajosConFechas.clear();
    trabajosAsignados.clear();
    trabajosModificados.clear();
    valoresOriginalesValidoDe.clear();
    horasTrabajos.clear();
    fechasFinTrabajos.clear();
    estadosPermisos.clear();
    // Limpiar mapa de solicitudes que empiezan por '4' al procesar nuevo archivo
    solicitudes4PorTexto.clear();
    
    const headers = jsonData[0];
    
    // DEBUG: Mostrar todos los headers
    console.log('=== HEADERS DEL EXCEL ===');
    headers.forEach((h, idx) => {
        console.log(`  Columna ${idx}: "${h}"`);
    });
    
    // Buscar índices de las columnas
    const indiceValidoDe = headers.findIndex(h => 
        h && h.toString().trim() === 'Válido de'
    );
    const indiceHoraInicio = headers.findIndex(h => 
        h && h.toString().trim() === 'Hora inicio validez'
    );
    const indiceStatusUsuario = headers.findIndex(h => 
        h && h.toString().trim() === 'Status de usuario'
    );
    
    console.log('Índice "Válido de":', indiceValidoDe);
    console.log('Índice "Hora inicio validez":', indiceHoraInicio);
    
    // DEBUG: Mostrar valores de las primeras filas para esas columnas
    if (jsonData.length > 1) {
        console.log('=== VALORES DE HORA EN PRIMERAS FILAS ===');
        for (let i = 1; i < Math.min(6, jsonData.length); i++) {
            const row = jsonData[i];
            console.log(`Fila ${i}: Válido de="${row[indiceValidoDe]}" (tipo: ${typeof row[indiceValidoDe]}), Hora="${row[indiceHoraInicio]}" (tipo: ${typeof row[indiceHoraInicio]})`);
        }
    }
    
    // NUEVO: Buscar índice de Creado por
    const indiceCreadoPor = headers.findIndex(h => 
        h && h.toString().trim() === 'Creado por'
    );
    // Buscar índice de Texto breve (para mapear solicitudes que empiezan por '4')
    const indiceTextoBreve = headers.findIndex(h => 
        h && h.toString().trim() === 'Texto breve'
    );
    // NUEVO: Buscar índice de Solicitud para filtrar
    const indiceSolicitud = headers.findIndex(h => 
        h && h.toString().trim() === 'Solicitud'
    );
    // NUEVO: Buscar índice de Utilización para detectar descargos
    const indiceUtilizacion = headers.findIndex(h => 
        h && h.toString().trim() === 'Utilización'
    );
    
    // DEBUG: Mostrar información sobre la columna Utilización
    console.log('=== DEPURACIÓN UTILIZACIÓN ===');
    console.log('Headers encontrados:', headers);
    console.log('Índice columna Utilización:', indiceUtilizacion);
    if (indiceUtilizacion === -1) {
        console.log('⚠️ COLUMNA "Utilización" NO ENCONTRADA. Buscando columnas similares...');
        headers.forEach((h, idx) => {
            if (h && h.toString().toLowerCase().includes('util')) {
                console.log(`  Posible columna similar en índice ${idx}: "${h}"`);
            }
        });
    }
    
    // Procesar cada fila (empezando desde la fila 1, ya que 0 son los headers)
    for (let i = 1; i < jsonData.length; i++) {
        const row = jsonData[i];
        if (!row || row.length === 0) continue;
        
        // Filtrar trabajos cuya Solicitud empieza por "4" -> registrar en mapa y no incluir en "trabajos"
        if (indiceSolicitud !== -1) {
            const solicitud = String(row[indiceSolicitud] || '').trim();
            if (solicitud.startsWith('4')) {
                // Obtener texto breve para agrupar
                let textoBr = '';
                if (indiceTextoBreve !== -1) {
                    textoBr = String(row[indiceTextoBreve] || '').trim();
                }
                const clave = textoBr.replace(/^HGPIe:\s*/i, '').trim().toLowerCase();
                if (!solicitudes4PorTexto.has(clave)) {
                    solicitudes4PorTexto.set(clave, []);
                }
                const arr = solicitudes4PorTexto.get(clave);
                if (!arr.includes(solicitud)) arr.push(solicitud);
                // No añadir a trabajos (comportamiento original)
                continue;
            }
        }
        
        // Crear objeto trabajo con todos los campos
        const trabajo = {};
        headers.forEach((header, index) => {
            if (header) {
                trabajo[header] = row[index] || '';
            }
        });
        
        // NUEVO: Determinar Tipo de Mantenimiento y Clase CSS
        const creadoPor = indiceCreadoPor !== -1 ? String(row[indiceCreadoPor] || '').trim() : '';
        const mapping = MTO_MAPPING[creadoPor] || MTO_MAPPING['DEFAULT'];
        trabajo.tipoMantenimiento = mapping.id;
        trabajo.claseTipo = mapping.clase;
        
        // NUEVO: Detectar si requiere descargo (Utilización = YU1)
        const utilizacion = indiceUtilizacion !== -1 ? String(row[indiceUtilizacion] || '').trim().toUpperCase() : '';
        trabajo.requiereDescargo = (utilizacion === 'YU1');
        
        // DEBUG: Mostrar valores de Utilización en primeros trabajos
        if (trabajos.length < 10 && indiceUtilizacion !== -1) {
            console.log(`Trabajo ${trabajos.length + 1} - Utilización: "${row[indiceUtilizacion]}" -> "${utilizacion}" -> requiereDescargo: ${trabajo.requiereDescargo}`);
        }

        // Añadir índice para referencia
        trabajo._indice = trabajos.length;
        trabajos.push(trabajo);
        
        // Guardar valor original de "Válido de"
        const valorValidoDe = indiceValidoDe !== -1 ? (row[indiceValidoDe] || '') : '';
        valoresOriginalesValidoDe.set(trabajo._indice, valorValidoDe);
        
        // DEBUG: Mostrar información de fechas de primeros trabajos
        if (trabajos.length <= 5) {
            console.log(`=== DEPURACIÓN FECHA Trabajo ${trabajos.length} ===`);
            console.log('  Valor original "Válido de":', valorValidoDe);
            console.log('  Tipo de dato:', typeof valorValidoDe);
            console.log('  Es Date?:', valorValidoDe instanceof Date);
            console.log('  Normalizada:', normalizarFecha(valorValidoDe));
        }
        
        // DEBUG: Mostrar primeros trabajos procesados
        if (trabajos.length <= 3) {
            console.log(`Trabajo ${trabajos.length}:`, {
                orden: trabajo['Orden'],
                textoBrve: trabajo['Texto breve'],
                validoDe: valorValidoDe,
                validoDeNormalizado: normalizarFecha(valorValidoDe),
                creadoPor: trabajo['Creado por'],
                tipoMto: trabajo.tipoMantenimiento
            });
        }
        
        // Cargar estado desde Status de usuario
        if (indiceStatusUsuario !== -1) {
            const status = String(row[indiceStatusUsuario] || '').trim().toUpperCase();
            if (status === 'AUTO') {
                estadosPermisos.set(trabajo._indice, 'AUTORIZADO');
            } else if (status === 'APRO') {
                estadosPermisos.set(trabajo._indice, 'APROBADO');
            } else {
                estadosPermisos.set(trabajo._indice, 'PENDIENTE');
            }
        } else {
            estadosPermisos.set(trabajo._indice, 'PENDIENTE');
        }
    }
}

// Distribuir trabajos entre listado y calendario según las fechas de la parada
function distribuirTrabajos() {
    trabajosConFechas.clear();
    trabajosAsignados.clear();
    
    // Obtener fechas de la parada
    const fechaInicioStr = fechaInicio.value;
    const fechaFinStr = fechaFin.value;
    
    // Si no hay rango de parada definido, dejar todo sin asignar (en listado)
    if (!fechaInicioStr || !fechaFinStr) {
        mostrarTrabajos();
        generarCalendario();
        return;
    }
    
    // No necesitamos convertir a Date para comparaciones de string YYYY-MM-DD si el formato es consistente,
    // pero para seguridad en comparaciones:
    
    trabajos.forEach(trabajo => {
        // Obtenemos la fecha ORIGINAL del trabajo (no modificada)
        // El requisito es re-evaluar la asignación basada en si CAEN DENTRO O NO.
        // Si el usuario modificó la fecha, ¿deberíamos respetar su modificación o la fecha original?
        // Asumiendo que "distribuir" es una operación de reset basada en criterio.
        // Pero si el usuario ya movió cosas en la herramienta, esas modificaciones están en "fechasFinTrabajos" o implícitas en "trabajosConFechas"?
        // No, el drag & drop actualiza "trabajosConFechas".
        // Vamos a usar la fecha ORIGINAL de "Válido de" para la distribución automática.
        
        const valorValidoDe = valoresOriginalesValidoDe.get(trabajo._indice);
        const fechaStr = normalizarFecha(valorValidoDe);
        
        if (fechaStr) {
            // Manejar múltiples fechas separadas por coma
            const fechas = fechaStr.split(',').map(f => f.trim()).filter(f => f);
            
            fechas.forEach(unaFecha => {
                // Verificar si la fecha cae dentro del rango de parada [fechaInicioStr, fechaFinStr]
                // Comparación lexicográfica funciona para formato YYYY-MM-DD
                if (unaFecha >= fechaInicioStr && unaFecha <= fechaFinStr) {
                    // DENTRO -> Asignar al calendario
                    if (!trabajosConFechas.has(unaFecha)) {
                        trabajosConFechas.set(unaFecha, []);
                    }
                    const lista = trabajosConFechas.get(unaFecha);
                    if (!lista.includes(trabajo._indice)) {
                        lista.push(trabajo._indice);
                    }
                    trabajosAsignados.add(trabajo._indice);
                    
                    // Nota: No marcamos como modificado porque es la asignación automática original
                }
                // FUERA -> No hacer nada, se queda en el listado (sin asignar)
            });
        }
    });

    // Refrescar la interfaz
    mostrarTrabajos();
    generarCalendario();
}

// Normalizar fecha a formato YYYY-MM-DD
function normalizarFecha(fecha) {
    if (!fecha) return null;
    
    // Si ya está en formato YYYY-MM-DD
    if (typeof fecha === 'string' && /^\d{4}-\d{2}-\d{2}/.test(fecha)) {
        return fecha.split(' ')[0]; // Tomar solo la parte de la fecha si hay hora
    }
    
    // Si es un objeto Date (de Excel con cellDates: true)
    if (fecha instanceof Date) {
        // Usar UTC para evitar problemas de zona horaria
        const ano = fecha.getUTCFullYear();
        const mes = String(fecha.getUTCMonth() + 1).padStart(2, '0');
        const dia = String(fecha.getUTCDate()).padStart(2, '0');
        return `${ano}-${mes}-${dia}`;
    }
    
    // Si es un número (serial de Excel) - CASO PRINCIPAL
    if (typeof fecha === 'number') {
        // Los seriales de Excel para fechas típicamente son > 1 (días desde 1900)
        // Si el número es muy pequeño (< 1), podría ser solo hora
        if (fecha < 1) {
            console.warn('Valor de fecha es solo hora (< 1):', fecha);
            return null;
        }
        
        // Convertir serial de Excel a fecha JavaScript
        // Excel cuenta desde 1 de enero de 1900, pero tiene un bug con el año bisiesto 1900
        // La fórmula: (serial - 25569) * 86400 * 1000 convierte a timestamp Unix
        // 25569 = días entre 1/1/1900 y 1/1/1970 (epoch Unix)
        const fechaExcel = new Date(Math.round((fecha - 25569) * 86400 * 1000));
        const ano = fechaExcel.getUTCFullYear();
        const mes = String(fechaExcel.getUTCMonth() + 1).padStart(2, '0');
        const dia = String(fechaExcel.getUTCDate()).padStart(2, '0');
        
        // Validar que el año sea razonable (entre 2000 y 2100)
        if (ano >= 2000 && ano <= 2100) {
            return `${ano}-${mes}-${dia}`;
        } else {
            console.warn('Fecha fuera de rango razonable:', fecha, '->', `${ano}-${mes}-${dia}`);
            return null;
        }
    }
    
    // Intentar parsear como string
    if (typeof fecha === 'string') {
        // Limpiar el string
        fecha = fecha.trim();
        
        // Si parece ser solo hora (HH:MM:SS), ignorar
        if (/^\d{1,2}:\d{2}(:\d{2})?$/.test(fecha)) {
            console.warn('Valor es solo hora, no fecha:', fecha);
            return null;
        }
        
        // Intentar diferentes formatos
        // YYYY-MM-DD
        let match = fecha.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (match) {
            return `${match[1]}-${match[2]}-${match[3]}`;
        }
        
        // DD/MM/YYYY (formato español)
        match = fecha.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (match) {
            return `${match[3]}-${String(match[2]).padStart(2, '0')}-${String(match[1]).padStart(2, '0')}`;
        }
        
        // DD.MM.YYYY (formato alemán)
        match = fecha.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})/);
        if (match) {
            return `${match[3]}-${String(match[2]).padStart(2, '0')}-${String(match[1]).padStart(2, '0')}`;
        }
        
        // YYYY/MM/DD
        match = fecha.match(/^(\d{4})\/(\d{2})\/(\d{2})/);
        if (match) {
            return `${match[1]}-${match[2]}-${match[3]}`;
        }
        
        // DD-MM-YYYY
        match = fecha.match(/^(\d{1,2})-(\d{1,2})-(\d{4})/);
        if (match) {
            return `${match[3]}-${String(match[2]).padStart(2, '0')}-${String(match[1]).padStart(2, '0')}`;
        }
        
        // MM/DD/YYYY (formato americano) - intentar detectar
        match = fecha.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
        if (match) {
            const num1 = parseInt(match[1]);
            const num2 = parseInt(match[2]);
            let ano = match[3];
            if (ano.length === 2) ano = '20' + ano;
            
            // Si el primer número > 12, es DD/MM/YYYY
            if (num1 > 12) {
                return `${ano}-${String(num2).padStart(2, '0')}-${String(num1).padStart(2, '0')}`;
            }
            // Si el segundo número > 12, es MM/DD/YYYY
            else if (num2 > 12) {
                return `${ano}-${String(num1).padStart(2, '0')}-${String(num2).padStart(2, '0')}`;
            }
            // Ambiguo - asumir DD/MM/YYYY (formato español)
            else {
                return `${ano}-${String(num2).padStart(2, '0')}-${String(num1).padStart(2, '0')}`;
            }
        }
        
        // Intentar parsear con Date como último recurso (usar UTC)
        const fechaParsed = new Date(fecha);
        if (!isNaN(fechaParsed.getTime())) {
            const ano = fechaParsed.getUTCFullYear();
            const mes = String(fechaParsed.getUTCMonth() + 1).padStart(2, '0');
            const dia = String(fechaParsed.getUTCDate()).padStart(2, '0');
            return `${ano}-${mes}-${dia}`;
        }
    }
    
    console.warn('No se pudo normalizar la fecha:', fecha, 'Tipo:', typeof fecha);
    return null;
}

// Mostrar la lista de trabajos (solo Texto breve)
function mostrarTrabajos() {
    trabajosList.innerHTML = '';
    
    // Hacer el listado un área de drop para devolver trabajos del calendario
    // Remover listeners anteriores si existen para evitar duplicados
    trabajosList.removeEventListener('dragover', handleDragOver);
    trabajosList.removeEventListener('drop', handleDropListado);
    trabajosList.removeEventListener('dragleave', handleDragLeave);
    
    // Añadir listeners
    trabajosList.addEventListener('dragover', handleDragOver);
    trabajosList.addEventListener('drop', handleDropListado);
    trabajosList.addEventListener('dragleave', handleDragLeave);
    trabajosList.classList.add('drop-zone');
    
    if (trabajos.length === 0) {
        trabajosList.innerHTML = '<p class="empty-message">No hay trabajos cargados</p>';
        return;
    }
    
    // Filtrar trabajos: solo mostrar los que NO han sido asignados y cumplen filtro de tipo y texto
    const trabajosFiltrados = trabajos.filter((trabajo, index) => {
        const noAsignado = !trabajosAsignados.has(trabajo._indice);
        
        // Filtro por tipo de mantenimiento
        const cumpleFiltroTipo = filtroTipos.has('TODOS') || filtroTipos.has(trabajo.tipoMantenimiento);
        
        // Filtro por texto en "Texto breve"
        let cumpleFiltroTexto = true;
        if (filtroTextoActivo && filtroTextoValor.trim() !== '') {
            const textoBreve = (trabajo['Texto breve'] || '').toLowerCase();
            const textoBuscar = filtroTextoValor.toLowerCase();
            cumpleFiltroTexto = textoBreve.includes(textoBuscar);
        }
        
        return noAsignado && cumpleFiltroTipo && cumpleFiltroTexto;
    });
    
    // Mostrar contador de trabajos restantes
    const contadorDiv = document.createElement('div');
    contadorDiv.className = 'contador-trabajos';
    contadorDiv.style.cssText = 'padding: 10px; background: #e3f2fd; border-radius: 6px; margin-bottom: 15px; font-weight: 600; color: #1976d2; text-align: center;';
    contadorDiv.textContent = `Trabajos pendientes: ${trabajosFiltrados.length}`;
    trabajosList.appendChild(contadorDiv);
    
    if (trabajosFiltrados.length === 0) {
        const emptyMsg = document.createElement('p');
        emptyMsg.className = 'empty-message';
        emptyMsg.textContent = 'No hay trabajos pendientes';
        trabajosList.appendChild(emptyMsg);
        return;
    }
    
    trabajosFiltrados.forEach((trabajo) => {
        const trabajoItem = document.createElement('div');
        trabajoItem.className = 'trabajo-item';
        
        // NUEVO: Añadir clase específica del tipo
        if (trabajo.claseTipo) {
            trabajoItem.classList.add(trabajo.claseTipo);
        }
        
        // Añadir clase si requiere descargo
        if (trabajo.requiereDescargo) {
            trabajoItem.classList.add('requiere-descargo');
        }
        
        trabajoItem.draggable = true;
        trabajoItem.dataset.indice = trabajo._indice; // Usar el índice original del trabajo
        
        // Obtener texto breve y eliminar prefijo "HGPIe: " si existe
        let textoBreve = trabajo['Texto breve'] || `Trabajo ${trabajo._indice + 1}`;
        //textoBreve = textoBreve.replace(/^HGPIe:\s*/i, ''); // Eliminar prefijo (case insensitive)
        
        // Añadir icono de descargo si aplica y crear contenido principal
        const partesContenido = [];
        if (trabajo.requiereDescargo) {
            partesContenido.push(`<span class="descargo-icon" title="Requiere acciones de aislamiento">🔒</span>`);
        }
        partesContenido.push(`<span class="texto-breve">${textoBreve}</span>`);

        // Añadir icono-link que abrirá la orden en una pestaña nueva
        const ordenParaUrl = (trabajo['Orden'] || '').toString().padStart(12, '0');
        const urlOrden = construirUrlOrden(ordenParaUrl);
        const linkIconHtml = `<a href="${urlOrden}" target="_blank" rel="noopener noreferrer" class="orden-link" title="Abrir orden ${ordenParaUrl}">🔗</a>`;
        partesContenido.push(linkIconHtml);

        // Añadir icono-link para la Solicitud
        const solicitudParaUrlList = (trabajo['Solicitud'] || '').toString().padStart(12, '0');
        const urlSolicitudList = construirUrlSolicitud(solicitudParaUrlList);
        const linkSolicitudHtml = `<a href="${urlSolicitudList}" target="_blank" rel="noopener noreferrer" class="solicitud-link" title="Abrir solicitud ${solicitudParaUrlList}">📎</a>`;
        partesContenido.push(linkSolicitudHtml);

        trabajoItem.innerHTML = partesContenido.join(' ');
        
        // Eventos de drag
        trabajoItem.addEventListener('dragstart', handleDragStart);
        trabajoItem.addEventListener('dragend', handleDragEnd);
        
        trabajosList.appendChild(trabajoItem);
    });
}

// Manejar drop en el listado (devolver trabajo del calendario)
function handleDropListado(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');
    
    const indiceTrabajo = parseInt(e.dataTransfer.getData('text/plain'));
    const fechaOrigen = e.dataTransfer.getData('text/fecha-origen');
    
    // Solo procesar si viene del calendario (tiene fecha de origen)
    if (!fechaOrigen) return;
    
    // Eliminar el trabajo de todas las fechas donde esté asignado
    for (const [fecha, indices] of trabajosConFechas.entries()) {
        const indice = indices.indexOf(indiceTrabajo);
        if (indice > -1) {
            indices.splice(indice, 1);
            trabajosConFechas.set(fecha, indices);
            // Actualizar visualización del día
            actualizarDiaCalendario(fecha);
        }
    }
    
    // Eliminar de trabajos asignados
    trabajosAsignados.delete(indiceTrabajo);
    
    // Verificar si la fecha cambió respecto al original
    const valorOriginal = valoresOriginalesValidoDe.get(indiceTrabajo) || '';
    const fechaActual = obtenerFechaTrabajo(indiceTrabajo);
    if (fechaActual === valorOriginal) {
        trabajosModificados.delete(indiceTrabajo);
    } else {
        trabajosModificados.add(indiceTrabajo);
    }
    
    // Actualizar listado para mostrar el trabajo nuevamente
    mostrarTrabajos();
    
    // (Gantt eliminado) -- no hay acción aquí
    
    // Actualizar estadísticas
    actualizarEstadisticasTrabajos();
}

// Generar calendarios basado en las fechas seleccionadas
function generarCalendario() {
    calendarioContainer.innerHTML = '';
    
    // Obtener fechas de los inputs
    const fechaInicioStr = fechaInicio.value;
    const fechaFinStr = fechaFin.value;
    
    if (!fechaInicioStr || !fechaFinStr) {
        // Valores por defecto si no hay fechas
        const enero = generarMesCalendario(2026, 0, 16, 31, true, 0, false, false, true);
        calendarioContainer.appendChild(enero);
        const febrero = generarMesCalendario(2026, 1, 1, 16, false, 1, true, true, false);
        calendarioContainer.appendChild(febrero);
        return;
    }
    
    const inicio = new Date(fechaInicioStr);
    const fin = new Date(fechaFinStr);
    
    if (inicio > fin) {
        alert('La fecha de inicio debe ser anterior a la fecha de fin');
        return;
    }
    
    // Generar calendarios para todos los meses entre inicio y fin
    const meses = [];
    let fechaActual = new Date(inicio);
    
    while (fechaActual <= fin) {
        const ano = fechaActual.getFullYear();
        const mes = fechaActual.getMonth();
        const dia = fechaActual.getDate();
        
        // Determinar el primer y último día del mes a mostrar
        let diaInicio = 1;
        let diaFin = new Date(ano, mes + 1, 0).getDate();
        
        // Si es el mes de inicio, empezar desde el día de inicio
        if (ano === inicio.getFullYear() && mes === inicio.getMonth()) {
            diaInicio = inicio.getDate();
        }
        
        // Si es el mes de fin, terminar en el día de fin
        if (ano === fin.getFullYear() && mes === fin.getMonth()) {
            diaFin = fin.getDate();
        }
        
        meses.push({ ano, mes, diaInicio, diaFin });
        
        // Avanzar al primer día del siguiente mes
        fechaActual = new Date(ano, mes + 1, 1);
    }
    
    // Generar calendarios para cada mes (continuo, sin saltos)
    meses.forEach(({ ano, mes, diaInicio, diaFin }, index) => {
        const esPrimerMes = index === 0;
        const esUltimoMes = index === meses.length - 1;
        const tieneMesAnterior = index > 0;
        const tieneMesSiguiente = index < meses.length - 1;
        const mesCalendario = generarMesCalendario(ano, mes, diaInicio, diaFin, esPrimerMes, index, esUltimoMes, tieneMesAnterior, tieneMesSiguiente);
        calendarioContainer.appendChild(mesCalendario);
    });
    
    // Igualar ancho de todos los días después de renderizar
    setTimeout(igualarAnchoDias, 0);
}

// Función para igualar el ancho de todos los días del calendario
function igualarAnchoDias() {
    const diasCalendario = document.querySelectorAll('.dia-calendario');
    const diasSemana = document.querySelectorAll('.dia-semana');
    
    if (diasCalendario.length === 0) return;
    
    // Usar ancho fijo de 275px para todos los días (compacto pero legible)
    const anchoFijo = 295;
    
    // Aplicar el ancho fijo a todos los días del calendario
    diasCalendario.forEach(dia => {
        dia.style.minWidth = anchoFijo + 'px';
        dia.style.width = anchoFijo + 'px';
    });
    
    // Aplicar el mismo ancho a los encabezados de días de la semana
    diasSemana.forEach(dia => {
        dia.style.minWidth = anchoFijo + 'px';
        dia.style.width = anchoFijo + 'px';
    });
}

// Actualizar calendario cuando cambien las fechas
function actualizarCalendario() {
    distribuirTrabajos();
    // Actualizar estadísticas
    actualizarEstadisticasTrabajos();
}

// Función para actualizar las estadísticas de trabajos
function actualizarEstadisticasTrabajos() {
    const estadisticasContainer = document.getElementById('estadisticasTrabajos');
    if (!estadisticasContainer) return;
    
    // Contar trabajos por estado
    let autorizados = 0;
    let aprobados = 0;
    let pendientes = 0;
    
    // Contar solo trabajos asignados al calendario
    trabajosAsignados.forEach(indice => {
        // Verificar filtro de tipo
        const trabajo = trabajos[indice];
        if (!filtroTipos.has('TODOS') && !filtroTipos.has(trabajo.tipoMantenimiento)) {
            return;
        }

        const estado = estadosPermisos.get(indice) || 'PENDIENTE';
        if (estado === 'AUTORIZADO') {
            autorizados++;
        } else if (estado === 'APROBADO') {
            aprobados++;
        } else {
            pendientes++;
        }
    });
    
    // Si no hay trabajos asignados, mostrar mensaje
    const totalTrabajos = autorizados + aprobados + pendientes;
    if (totalTrabajos === 0) {
        estadisticasContainer.innerHTML = '<span class="estadistica-texto">Sin trabajos asignados</span>';
        return;
    }
    
    // Crear HTML de estadísticas
    estadisticasContainer.innerHTML = `
        <div class="estadistica-item">
            <span class="estadistica-label">Total:</span>
            <span class="estadistica-valor">${totalTrabajos}</span>
        </div>
        <div class="estadistica-item estado-autorizado" title="Permiso de trabajo aprobado con todas las firmas">
            <span class="estadistica-label">Autorizados:</span>
            <span class="estadistica-valor">${autorizados}</span>
        </div>
        <div class="estadistica-item estado-aprobado" title="Permiso de trabajo aprobado pendiente de alguna firma">
            <span class="estadistica-label">Aprobados:</span>
            <span class="estadistica-valor">${aprobados}</span>
        </div>
        <div class="estadistica-item estado-pendiente" title="Permiso de trabajo pendiente">
            <span class="estadistica-label">Pendientes:</span>
            <span class="estadistica-valor">${pendientes}</span>
        </div>
    `;
}

// Generar un mes del calendario
// diaInicio y diaFin: rango de días a mostrar (null = todos los días del mes)
// esPrimerMes: si es true, mostrar los días de la semana
// indiceMes: índice del mes para alternar fondos (0, 1, 2, ...)
// esUltimoMes: si es true, puede mostrar días de relleno del mes siguiente
// tieneMesAnterior: si es true, hay un mes anterior en el rango (no añadir días del mes anterior)
// tieneMesSiguiente: si es true, hay un mes siguiente en el rango (no añadir días del mes siguiente)
function generarMesCalendario(ano, mes, diaInicio = null, diaFin = null, esPrimerMes = true, indiceMes = 0, esUltimoMes = true, tieneMesAnterior = false, tieneMesSiguiente = false) {
    const contenedorMes = document.createElement('div');
    contenedorMes.className = 'mes-calendario';
    
    // Añadir clase para alternar fondos (par/impar)
    if (indiceMes % 2 === 0) {
        contenedorMes.classList.add('mes-par');
    } else {
        contenedorMes.classList.add('mes-impar');
    }
    
    // NO mostrar header del mes (eliminado para calendario continuo)
    
    // Días de la semana (empezando en lunes) - solo mostrar en el primer mes
    if (esPrimerMes) {
        const diasSemana = document.createElement('div');
        diasSemana.className = 'dias-semana';
        const nombresDias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
        nombresDias.forEach(dia => {
            const diaSemana = document.createElement('div');
            diaSemana.className = 'dia-semana';
            diaSemana.textContent = dia;
            diasSemana.appendChild(diaSemana);
        });
        contenedorMes.appendChild(diasSemana);
    }
    
    // Grid de días
    const diasMes = document.createElement('div');
    diasMes.className = 'dias-mes';
    
    // Determinar el primer día a mostrar
    const primerDiaAMostrar = diaInicio !== null ? diaInicio : 1;
    const ultimoDiaAMostrar = diaFin !== null ? diaFin : new Date(ano, mes + 1, 0).getDate();
    
    // Primer día a mostrar
    const primerDia = new Date(ano, mes, primerDiaAMostrar);
    // Convertir día de la semana: domingo=0 -> lunes=0 (lunes=0, martes=1, ..., domingo=6)
    const diaSemanaJS = primerDia.getDay(); // 0=domingo, 1=lunes, ..., 6=sábado
    const diaSemanaInicio = (diaSemanaJS + 6) % 7; // 0=lunes, 1=martes, ..., 6=domingo
    
    // Días del mes anterior (relleno) - NUNCA mostrar días del mes anterior si hay un mes anterior en el rango
    // Si hay un mes anterior, ese mes ya generó sus días, así que solo mostrar celdas vacías
    if (diaSemanaInicio > 0) {
        if (!tieneMesAnterior && primerDiaAMostrar === 1) {
            // Solo mostrar días del mes anterior si NO hay mes anterior en el rango Y empezamos desde el día 1
            const ultimoDiaMesAnterior = new Date(ano, mes, 0);
            const ultimoDiaNumero = ultimoDiaMesAnterior.getDate();
            const diaSemanaUltimoJS = ultimoDiaMesAnterior.getDay();
            const diaSemanaUltimo = (diaSemanaUltimoJS + 6) % 7; // Convertir a lunes=0
            
            // Calcular cuántos días del mes anterior necesitamos mostrar
            const diasARellenar = diaSemanaInicio;
            
            for (let i = diasARellenar - 1; i >= 0; i--) {
                const dia = document.createElement('div');
                dia.className = 'dia-calendario otro-mes';
                
                // Calcular qué día de la semana queremos mostrar (0=lunes, 1=martes, etc.)
                const diaSemanaDeseado = diaSemanaInicio - 1 - i;
                
                // Calcular el día del mes anterior que corresponde a ese día de la semana
                // Convertir de vuelta a formato JS (domingo=0) para el cálculo
                const diaSemanaDeseadoJS = (diaSemanaDeseado + 1) % 7;
                const diaSemanaUltimoJSOriginal = ultimoDiaMesAnterior.getDay();
                const diferencia = (diaSemanaUltimoJSOriginal - diaSemanaDeseadoJS + 7) % 7;
                const diaNumero = ultimoDiaNumero - diferencia;
                
                dia.textContent = diaNumero;
                diasMes.appendChild(dia);
            }
        } else {
            // Si hay mes anterior o no empezamos desde el día 1, mostrar celdas vacías
            for (let i = 0; i < diaSemanaInicio; i++) {
                const dia = document.createElement('div');
                dia.className = 'dia-calendario otro-mes';
                dia.textContent = ''; // Celda vacía
                diasMes.appendChild(dia);
            }
        }
    }
    
    // Días del mes actual (solo el rango especificado)
    const hoy = new Date();
    const hoyStr = formatearFecha(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());

    for (let dia = primerDiaAMostrar; dia <= ultimoDiaAMostrar; dia++) {
        const diaElement = document.createElement('div');
        diaElement.className = 'dia-calendario';
        
        const fechaStr = formatearFecha(ano, mes, dia);
        const fechaDia = new Date(ano, mes, dia);
        fechaDia.setHours(0, 0, 0, 0);
        const hoyNormalizado = new Date(hoy);
        hoyNormalizado.setHours(0, 0, 0, 0);
        
        if (fechaStr === hoyStr) {
            diaElement.classList.add('dia-actual');
        } else if (fechaDia < hoyNormalizado) {
            diaElement.classList.add('dia-pasado');
        }
        diaElement.dataset.fecha = fechaStr;
        
        const numeroDia = document.createElement('div');
        numeroDia.className = 'numero-dia';
        // Mostrar día/mes en formato "16/Ene" (mes en texto)
        const nombresMesesAbrev = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre   '];
        numeroDia.textContent = `${dia} de ${nombresMesesAbrev[mes]} de ${ano}`;
        diaElement.appendChild(numeroDia);
        // Contenedor para estadísticas del día (Autorizados / Resto)
        const estadisticaDia = document.createElement('div');
        estadisticaDia.className = 'estadistica-dia';
        estadisticaDia.style.cssText = 'display:flex; gap:10px; margin:6px 0 10px 0; font-size:13px; align-items:center;';
        // Valores iniciales (se actualizarán en mostrarTrabajosEnDia)
        estadisticaDia.innerHTML = `<div class="estadistica-dia-item" title="Permisos autorizados"><strong>Autorizados:</strong> <span class="estadistica-valor">0</span></div><div class="estadistica-dia-item" title="Permisos no autorizados"> <strong>Resto:</strong> <span class="estadistica-valor">0</span></div>`;
        diaElement.appendChild(estadisticaDia);
        
        // Contenedor para trabajos del día
        const trabajosDia = document.createElement('div');
        trabajosDia.className = 'trabajos-dia';
        diaElement.appendChild(trabajosDia);
        
        // Mostrar trabajos asignados a este día
        mostrarTrabajosEnDia(trabajosDia, fechaStr);
        
        // Eventos de drop
        diaElement.addEventListener('dragover', handleDragOver);
        diaElement.addEventListener('drop', handleDrop);
        diaElement.addEventListener('dragleave', handleDragLeave);
        
        diasMes.appendChild(diaElement);
    }
    
    // Días del mes siguiente (relleno) - NUNCA mostrar días del mes siguiente si hay un mes siguiente en el rango
    // Si hay un mes siguiente, ese mes ya generará sus días, así que solo mostrar celdas vacías
    const ultimoDiaDelMes = new Date(ano, mes + 1, 0).getDate();
    const totalCeldas = diasMes.children.length;
    const semanasCompletas = Math.ceil(totalCeldas / 7);
    const celdasNecesarias = semanasCompletas * 7;
    const celdasRestantes = celdasNecesarias - totalCeldas;
    
    if (celdasRestantes > 0) {
        // Solo mostrar días del mes siguiente si NO hay mes siguiente Y es el último mes Y terminamos en el último día
        if (!tieneMesSiguiente && esUltimoMes && ultimoDiaAMostrar === ultimoDiaDelMes) {
            // Solo en este caso, mostrar días del mes siguiente
            for (let dia = 1; dia <= celdasRestantes; dia++) {
                const diaElement = document.createElement('div');
                diaElement.className = 'dia-calendario otro-mes';
                diaElement.textContent = dia;
                diasMes.appendChild(diaElement);
            }
        } else {
            // En cualquier otro caso (hay mes siguiente o no terminamos en el último día), mostrar celdas vacías
            for (let dia = 1; dia <= celdasRestantes; dia++) {
                const diaElement = document.createElement('div');
                diaElement.className = 'dia-calendario otro-mes';
                diaElement.textContent = ''; // Celda vacía
                diasMes.appendChild(diaElement);
            }
        }
    }
    
    contenedorMes.appendChild(diasMes);
    return contenedorMes;
}

// Formatear fecha como YYYY-MM-DD
function formatearFecha(ano, mes, dia) {
    const mesStr = String(mes + 1).padStart(2, '0');
    const diaStr = String(dia).padStart(2, '0');
    return `${ano}-${mesStr}-${diaStr}`;
}

// Obtener hora de un trabajo
function obtenerHoraTrabajo(indice) {
    // Si hay una hora modificada, usar esa
    if (horasTrabajos.has(indice)) {
        return horasTrabajos.get(indice);
    }
    
    // Usar la hora del trabajo directamente
    const trabajo = trabajos[indice];
    const hora = trabajo['Hora inicio validez'];
    
    // Si está vacío, devolver 00:00
    if (hora === null || hora === undefined || hora === '') {
        return '00:00';
    }
    
    // Si es número (formato Excel), convertir
    if (typeof hora === 'number') {
        const totalMinutos = Math.round(hora * 24 * 60);
        const h = Math.floor(totalMinutos / 60) % 24;
        const m = totalMinutos % 60;
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    }
    
    // Si es string con formato H:MM:SS o HH:MM:SS, extraer solo HH:MM
    const horaStr = String(hora).trim();
    const match = horaStr.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
    if (match) {
        const h = parseInt(match[1]);
        const m = parseInt(match[2]);
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    }
    
    return horaStr;
}

// Normalizar hora a formato HH:MM
function normalizarHora(hora) {
    // Si es null, undefined o string vacío, devolver 00:00
    if (hora === null || hora === undefined || hora === '') return '00:00';
    
    // Si es un número (formato Excel: 0 = 00:00, 0.29166667 = 7:00)
    if (typeof hora === 'number') {
        // Excel almacena horas como fracción del día
        const totalMinutos = Math.round(hora * 24 * 60);
        const h = Math.floor(totalMinutos / 60) % 24;
        const m = totalMinutos % 60;
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    }
    
    // Convertir a string
    const horaStr = String(hora).trim();
    
    // Si es string vacío, devolver 00:00
    if (horaStr === '') return '00:00';
    
    // Si es "0" como string, convertir a 00:00
    if (horaStr === '0') return '00:00';
    
    // Si parece un número decimal como string (0.xxxxx)
    if (/^[\d.]+$/.test(horaStr)) {
        const horaNum = parseFloat(horaStr);
        if (!isNaN(horaNum)) {
            const totalMinutos = Math.round(horaNum * 24 * 60);
            const h = Math.floor(totalMinutos / 60) % 24;
            const m = totalMinutos % 60;
            return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
        }
    }
    
    // Devolver como string directamente
    return horaStr;
}

// Construir URL dinámica para una Orden (rellena con ceros a la izquierda si hace falta)
function construirUrlOrden(orden) {
    if (!orden) return '';
    // Asegurar que orden sea string y tenga al menos 12 caracteres con ceros a la izquierda
    const ordenStr = String(orden).trim();
    const ordenPad = ordenStr.padStart(12, '0');
    const base = 'https://gadea.naturgy.com/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html';
    const params = '?sap-client=300&sap-language=ES#MaintenanceOrder-display?AUFNR=';
    return `${base}${params}${ordenPad}&sap-app-origin-hint=&sap-ui-technology=WDA`;
}

// Construir URL dinámica para una Solicitud (rellena con ceros a la izquierda si hace falta)
function construirUrlSolicitud(solicitud) {
    if (!solicitud) return '';
    const solStr = String(solicitud).trim();
    const solPad = solStr.padStart(12, '0');
    const base = 'https://gadea.naturgy.com/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html';
    const params = '?sap-client=300&sap-language=ES#GadeaWCM-openWCTL?WCSWAPI-WAPINR=';
    return `${base}${params}${solPad}&sap-app-origin-hint=&sap-ui-technology=GUI`;
}

// Comparar horas para ordenar
function compararHoras(hora1, hora2) {
    const [h1, m1] = hora1.split(':').map(Number);
    const [h2, m2] = hora2.split(':').map(Number);
    
    if (h1 !== h2) {
        return h1 - h2;
    }
    return m1 - m2;
}

// Mostrar trabajos asignados a un día
function mostrarTrabajosEnDia(contenedor, fechaStr) {
    contenedor.innerHTML = '';
    
    const indicesTrabajos = trabajosConFechas.get(fechaStr) || [];
    // Calcular estadística por día: autorizados vs resto (respetando filtroTipos)
    try {
        const contenedorDia = contenedor.parentElement; // el "diaElement"
        if (contenedorDia) {
            const estadisticaDiv = contenedorDia.querySelector('.estadistica-dia');
            if (estadisticaDiv) {
                let autorizados = 0;
                let total = 0;
                indicesTrabajos.forEach(ind => {
                    const trabajo = trabajos[ind];
                    // respetar filtro de tipo
                    if (!filtroTipos.has('TODOS') && !filtroTipos.has(trabajo.tipoMantenimiento)) return;
                    total++;
                    const estado = (estadosPermisos.get(ind) || 'PENDIENTE');
                    if (estado === 'AUTORIZADO') autorizados++;
                });
                const resto = Math.max(0, total - autorizados);
                // Actualizar HTML del bloque de estadísticas
                estadisticaDiv.innerHTML = `<div class="estadistica-dia-item" title="Permisos autorizados"><strong>Autorizados:</strong> <span class="estadistica-valor">${autorizados}</span></div><div class="estadistica-dia-item" title="Permisos no autorizados"> <strong>Resto:</strong> <span class="estadistica-valor">${resto}</span></div>`;
            }
        }
    } catch (err) {
        console.warn('Error actualizando estadística diaria:', err);
    }
    
    // Ordenar trabajos por hora
    const trabajosConHora = indicesTrabajos.map(indice => {
        const trabajo = trabajos[indice];
        const hora = normalizarHora(obtenerHoraTrabajo(indice));
        return { indice, hora, trabajo };
    });
    
    trabajosConHora.sort((a, b) => compararHoras(a.hora, b.hora));
    
    trabajosConHora.forEach(({ indice, hora, trabajo }) => {
        // NUEVO: Filtro global
        if (!filtroTipos.has('TODOS') && !filtroTipos.has(trabajo.tipoMantenimiento)) {
            return;
        }

        const trabajoElement = document.createElement('div');
        trabajoElement.className = 'trabajo-en-calendario';
        
        // NUEVO: Añadir clase de tipo
        if (trabajo.claseTipo) {
            trabajoElement.classList.add(trabajo.claseTipo);
        }
        
        trabajoElement.draggable = true;
        trabajoElement.dataset.indice = indice;
        trabajoElement.dataset.fechaOrigen = fechaStr; // Guardar fecha de origen
        
        // Obtener texto breve y eliminar prefijo "HGPIe: " si existe
        let textoBreve = trabajo['Texto breve'] || `Trabajo ${indice + 1}`;
        //textoBreve = textoBreve.replace(/^HGPIe:\s*/i, ''); // Eliminar prefijo (case insensitive)
        
        // Obtener Orden y Solicitud
        const orden = trabajo['Orden'] || '';
        const solicitud = trabajo['Solicitud'] || '';
        
        // Crear contenedor para la primera línea (hora, Orden, Solicitud)
        const primeraLinea = document.createElement('div');
        primeraLinea.className = 'trabajo-primera-linea';
        
        const horaContainer = document.createElement('div');
        horaContainer.className = 'trabajo-hora';
        horaContainer.textContent = `⏰ ${hora}`;
        
        const ordenContainer = document.createElement('div');
        ordenContainer.className = 'trabajo-orden';
        ordenContainer.textContent = `📋 ${orden}`;
        ordenContainer.title = 'Clic para copiar número de orden';
        ordenContainer.style.cursor = 'pointer';
        ordenContainer.addEventListener('click', (e) => {
            e.stopPropagation();
            if (orden) {
                navigator.clipboard.writeText(orden).then(() => {
                    const textoOriginal = ordenContainer.textContent;
                    ordenContainer.textContent = '✅ Copiado!';
                    setTimeout(() => {
                        ordenContainer.textContent = textoOriginal;
                    }, 1000);
                }).catch(err => {
                    console.error('Error al copiar:', err);
                });
            }
        });
        
        const solicitudContainer = document.createElement('div');
        solicitudContainer.className = 'trabajo-solicitud';
        solicitudContainer.textContent = `📄 ${solicitud}`;
        solicitudContainer.title = 'Clic para copiar número de solicitud';
        solicitudContainer.style.cursor = 'pointer';
        solicitudContainer.addEventListener('click', (e) => {
            e.stopPropagation(); // Evitar que se propague al contenedor padre
            if (solicitud) {
                navigator.clipboard.writeText(solicitud).then(() => {
                    // Feedback visual temporal
                    const textoOriginal = solicitudContainer.textContent;
                    solicitudContainer.textContent = '✅ Copiado!';
                    setTimeout(() => {
                        solicitudContainer.textContent = textoOriginal;
                    }, 1000);
                }).catch(err => {
                    console.error('Error al copiar:', err);
                });
            }
        });
        
        primeraLinea.appendChild(horaContainer);
        primeraLinea.appendChild(ordenContainer);
        // Añadir icono-link para abrir la orden en una nueva pestaña
        const ordenParaUrlCal = (orden || '').toString().padStart(12, '0');
        const urlOrdenCal = construirUrlOrden(ordenParaUrlCal);
        const linkOrdenContainer = document.createElement('div');
        linkOrdenContainer.className = 'trabajo-orden-link';
        linkOrdenContainer.innerHTML = `<a href="${urlOrdenCal}" target="_blank" rel="noopener noreferrer" title="Abrir orden ${ordenParaUrlCal}">🔗</a>`;
        primeraLinea.appendChild(linkOrdenContainer);
        // Añadir Solicitud y su icono-link en orden: número de solicitud + icono
        primeraLinea.appendChild(solicitudContainer);
        const solicitudParaUrlCal = (solicitud || '').toString().padStart(12, '0');
        const urlSolicitudCal = construirUrlSolicitud(solicitudParaUrlCal);
        const linkSolicitudCal = document.createElement('div');
        linkSolicitudCal.className = 'trabajo-solicitud-link';
        linkSolicitudCal.innerHTML = `<a href="${urlSolicitudCal}" target="_blank" rel="noopener noreferrer" title="Abrir solicitud ${solicitudParaUrlCal}">📎</a>`;
        primeraLinea.appendChild(linkSolicitudCal);
        
        // NUEVO: Añadir icono de descargo si Utilización = YU1
        if (trabajo.requiereDescargo) {
            const descargoContainer = document.createElement('div');
            descargoContainer.className = 'trabajo-descargo';
            descargoContainer.textContent = '🔒';
            descargoContainer.title = 'Requiere acciones de aislamiento';
            primeraLinea.appendChild(descargoContainer);
            trabajoElement.classList.add('requiere-descargo');
        }
        
        // Crear contenedor para el texto (segunda línea)
        const textoContainer = document.createElement('div');
        textoContainer.className = 'trabajo-texto';
        textoContainer.textContent = textoBreve;
        textoContainer.title = 'Clic para copiar texto del trabajo';
        textoContainer.style.cursor = 'pointer';
        textoContainer.addEventListener('click', (e) => {
            e.stopPropagation();
            if (textoBreve) {
                navigator.clipboard.writeText(textoBreve).then(() => {
                    const textoOriginal = textoContainer.textContent;
                    textoContainer.textContent = '✅ Copiado!';
                    setTimeout(() => {
                        textoContainer.textContent = textoOriginal;
                    }, 1000);
                }).catch(err => {
                    console.error('Error al copiar:', err);
                });
            }
        });
        
        trabajoElement.appendChild(primeraLinea);
        trabajoElement.appendChild(textoContainer);
        trabajoElement.title = `${textoBreve} - ${hora}`;
        
        // Eventos de drag para trabajos en el calendario
        trabajoElement.addEventListener('dragstart', handleDragStartCalendario);
        trabajoElement.addEventListener('dragend', handleDragEnd);
        
        // Aplicar color según el estado del permiso
        const estadoPermiso = estadosPermisos.get(indice) || 'PENDIENTE';
        trabajoElement.dataset.estado = estadoPermiso;
        if (estadoPermiso === 'AUTORIZADO') {
            trabajoElement.classList.add('estado-autorizado');
        } else if (estadoPermiso === 'APROBADO') {
            trabajoElement.classList.add('estado-aprobado');
        } else {
            trabajoElement.classList.add('estado-pendiente');
        }
        
        // Evento de clic derecho: mostrar modal con datos importantes (Orden, Solicitud, Texto breve)
        // Anteriormente abría el editor de hora; ahora mostramos un modal con botones de copiar y un botón Cerrar
        trabajoElement.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            mostrarDetallesTrabajoContextMenu(indice, trabajoElement, fechaStr);
        });
        
        contenedor.appendChild(trabajoElement);
    });
}

// Mostrar editor de hora
function mostrarEditorHora(indice, elemento, horaActual, fechaInicioStr, estadoActual = 'SOLICITADO') {
    // Obtener fecha de finalización actual o calcular por defecto (día siguiente)
    const trabajo = trabajos[indice];
    let fechaFinActual = '';
    
    if (fechasFinTrabajos.has(indice)) {
        fechaFinActual = fechasFinTrabajos.get(indice);
    } else if (trabajo['Validez a']) {
        fechaFinActual = normalizarFecha(trabajo['Validez a']);
    }
    
    // Si no hay fecha de finalización, calcular el día siguiente de la fecha de inicio
    if (!fechaFinActual && fechaInicioStr) {
        const fechaInicio = new Date(fechaInicioStr);
        fechaInicio.setDate(fechaInicio.getDate() + 1);
        const ano = fechaInicio.getFullYear();
        const mes = String(fechaInicio.getMonth() + 1).padStart(2, '0');
        const dia = String(fechaInicio.getDate()).padStart(2, '0');
        fechaFinActual = `${ano}-${mes}-${dia}`;
    }
    
    // Crear modal/editor de hora, fecha de finalización y estado del permiso
    const editor = document.createElement('div');
    editor.className = 'editor-hora';
    editor.innerHTML = `
        <div class="editor-hora-contenido">
            <h3>Editar trabajo</h3>
            <div style="margin-bottom: 15px;">
                <label for="horaInput" style="display: block; margin-bottom: 5px; font-weight: 600;">Hora de inicio:</label>
                <input type="time" id="horaInput" value="${horaActual}" class="hora-input" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" />
            </div>
            <div style="margin-bottom: 15px;">
                <label for="fechaFinInput" style="display: block; margin-bottom: 5px; font-weight: 600;">Validez a:</label>
                <input type="date" id="fechaFinInput" value="${fechaFinActual}" class="fecha-input" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" />
            </div>
            <div style="margin-bottom: 15px;">
                <label for="estadoPermisoInput" style="display: block; margin-bottom: 5px; font-weight: 600;">Estado del permiso:</label>
                <select id="estadoPermisoInput" class="estado-input" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px;">
                    <option value="SOLICITADO" ${estadoActual === 'SOLICITADO' ? 'selected' : ''}>SOLICITADO</option>
                    <option value="AUTORIZADO" ${estadoActual === 'AUTORIZADO' ? 'selected' : ''}>AUTORIZADO</option>
                </select>
            </div>
            <div class="editor-hora-botones">
                <button class="btn-guardar-hora">Guardar</button>
                <button class="btn-cancelar-hora">Cancelar</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(editor);
    
    const horaInput = editor.querySelector('#horaInput');
    const fechaFinInput = editor.querySelector('#fechaFinInput');
    const estadoPermisoInput = editor.querySelector('#estadoPermisoInput');
    const btnGuardar = editor.querySelector('.btn-guardar-hora');
    const btnCancelar = editor.querySelector('.btn-cancelar-hora');
    
    // Guardar hora, fecha de finalización y estado del permiso
    btnGuardar.addEventListener('click', () => {
        const nuevaHora = normalizarHora(horaInput.value);
        horasTrabajos.set(indice, nuevaHora);
        
        // Guardar fecha de finalización si se ha modificado
        const nuevaFechaFin = fechaFinInput.value;
        if (nuevaFechaFin) {
            fechasFinTrabajos.set(indice, nuevaFechaFin);
        }
        
        // Guardar estado del permiso
        const nuevoEstado = estadoPermisoInput.value;
        estadosPermisos.set(indice, nuevoEstado);
        
        // Actualizar visualización
        const fechaOrigen = elemento.dataset.fechaOrigen;
        if (fechaOrigen) {
            const contenedor = elemento.closest('.trabajos-dia');
            if (contenedor) {
                mostrarTrabajosEnDia(contenedor, fechaOrigen);
            }
        }
        
        // (Gantt eliminado)
        
        // Actualizar estadísticas
        actualizarEstadisticasTrabajos();
        
        document.body.removeChild(editor);
    });
    
    // Cancelar
    btnCancelar.addEventListener('click', () => {
        document.body.removeChild(editor);
    });
    
    // Cerrar al hacer clic fuera
    editor.addEventListener('click', (e) => {
        if (e.target === editor) {
            document.body.removeChild(editor);
        }
    });
    
    // Enfocar el input de hora
    horaInput.focus();
}

// Mostrar modal con detalles importantes al hacer clic derecho
function mostrarDetallesTrabajoContextMenu(indice, elemento, fechaStr) {
    const trabajo = trabajos[indice];
    if (!trabajo) return;

    const orden = trabajo['Orden'] || '';
    const solicitud = trabajo['Solicitud'] || '';
    const textoBreve = trabajo['Texto breve'] || '';

    // Calcular CyMP (solicitudes que empiezan por '4' y coinciden por Texto breve)
    const cympArray = calcularCyMPParaTrabajo(indice);
    const cympStr = (cympArray && cympArray.length > 0) ? cympArray.join(', ') : '';

    // Crear modal (markup con clases para estilos desde styles.css)
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    const modal = document.createElement('div');
    modal.className = 'modal-detalles';

    modal.innerHTML = `
        <h3>Detalles del trabajo</h3>
        <div class="modal-row">
            <div class="modal-label"><strong>Orden:</strong><div id="modal-orden" class="modal-value">${orden}</div></div>
            <button id="btn-copiar-orden" class="modal-btn modal-btn-copy modal-small-btn">Copiar</button>
        </div>
        <div class="modal-row">
            <div class="modal-label"><strong>Solicitud:</strong><div id="modal-solicitud" class="modal-value">${solicitud}</div></div>
            <button id="btn-copiar-solicitud" class="modal-btn modal-btn-copy modal-small-btn">Copiar</button>
        </div>
        <div class="modal-row">
            <div class="modal-label"><strong>CyMP:</strong><div id="modal-cymp" class="modal-value">${cympStr}</div></div>
            <button id="btn-copiar-cymp" class="modal-btn modal-btn-copy modal-small-btn">Copiar</button>
        </div>
        <div class="modal-row">
            <div class="modal-label"><strong>Texto breve:</strong><div id="modal-texto" class="modal-value">${textoBreve}</div></div>
            <button id="btn-copiar-texto" class="modal-btn modal-btn-copy" style="height:40px;">Copiar</button>
        </div>
        <div class="modal-row">
            <div class="modal-label"><strong>Aislamientos:</strong><div id="modal-aislamientos" class="modal-value"></div></div>
            <button id="btn-copiar-aislamientos" class="modal-btn modal-btn-copy" style="height:40px;">Copiar</button>
        </div>
        <div class="modal-actions">
            <button id="btn-cerrar-modal" class="modal-btn modal-btn-close">Cerrar</button>
        </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Funciones copiar
    const copiarTexto = (text, button) => {
        if (!text) return;
        navigator.clipboard.writeText(text).then(() => {
            const original = button.textContent;
            button.textContent = '✅ Copiado';
            setTimeout(() => { button.textContent = original; }, 1000);
        }).catch(err => {
            console.error('Error copiando al portapapeles', err);
        });
    };

    const btnOrden = modal.querySelector('#btn-copiar-orden');
    const btnSolicitud = modal.querySelector('#btn-copiar-solicitud');
    const btnTexto = modal.querySelector('#btn-copiar-texto');
    const btnCyMP = modal.querySelector('#btn-copiar-cymp');
    const btnAislamientos = modal.querySelector('#btn-copiar-aislamientos');
    const btnCerrar = modal.querySelector('#btn-cerrar-modal');

    btnOrden.addEventListener('click', (e) => { e.stopPropagation(); copiarTexto(orden, btnOrden); });
    btnSolicitud.addEventListener('click', (e) => { e.stopPropagation(); copiarTexto(solicitud, btnSolicitud); });
    btnTexto.addEventListener('click', (e) => { e.stopPropagation(); copiarTexto(textoBreve, btnTexto); });
    if (btnCyMP) {
        btnCyMP.addEventListener('click', (e) => { e.stopPropagation(); copiarTexto(cympStr, btnCyMP); });
    }
    // Mostrar aislamientos asignados a la solicitud de este trabajo
    const modalAislamientosDiv = modal.querySelector('#modal-aislamientos');
    const solicitudKey = (trabajo['Solicitud'] || '').toString().trim();
    const aislamientos = aislamientosPorSolicitud.get(solicitudKey) || [];
    if (modalAislamientosDiv) {
        if (aislamientos.length === 0) {
            modalAislamientosDiv.textContent = 'Sin aislamientos asignados';
        } else {
            // Mostrar cada aislamiento en nueva línea con número - descripción - estados
            modalAislamientosDiv.innerHTML = aislamientos.map(a => `${a.numero} — ${a.descripcion} <br><small>${a.estados}</small>`).join('<hr style="border:none;border-top:1px solid #eee;margin:6px 0;">');
        }
    }
    if (btnAislamientos) {
        btnAislamientos.addEventListener('click', (e) => { e.stopPropagation(); const txt = aislamientos.map(a => `${a.numero} | ${a.descripcion} | ${a.estados}`).join('\n'); copiarTexto(txt, btnAislamientos); });
    }

    const cerrar = () => {
        if (overlay && overlay.parentElement) document.body.removeChild(overlay);
        // quitar listener de teclado
        document.removeEventListener('keydown', onKeyDownClose);
    };

    btnCerrar.addEventListener('click', (e) => { e.stopPropagation(); cerrar(); });

    // Cerrar al hacer clic fuera del modal
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) cerrar();
    });

    // Evitar propagación del click dentro del modal para no cerrar
    modal.addEventListener('click', (e) => { e.stopPropagation(); });

    // Cerrar con tecla Escape
    function onKeyDownClose(e) {
        if (e.key === 'Escape' || e.key === 'Esc') {
            cerrar();
        }
    }
    document.addEventListener('keydown', onKeyDownClose);
}

// Manejar subida de fichero .txt con aislamientos
function handleTxtUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        const parsed = parsearAislamientosTxt(text);
        if (parsed) {
            aislamientosPorSolicitud.clear();
            // parsed tiene formato { solicitudId: [ { numero, descripcion, estados } ] }
            Object.keys(parsed).forEach(k => {
                aislamientosPorSolicitud.set(k, parsed[k]);
            });

            // Asignar aislamientos a los trabajos actuales (por número de solicitud)
            asignarAislamientosATrabajos();

            alert('Aislamientos parseados y asignados correctamente');
            // Actualizar UI (listado y calendario)
            mostrarTrabajos();
            // Refrescar días mostrados
            trabajosConFechas.forEach((_, fecha) => actualizarDiaCalendario(fecha));
            // Refrescar pestaña de aislamientos si está visible o no
            if (typeof renderizarAislamientos === 'function') {
                renderizarAislamientos();
            }
        } else {
            alert('No se pudieron parsear los aislamientos');
        }
    };
    reader.readAsText(file, 'utf-8');
}

// Parsear el fichero txt con la estructura jerárquica de la muestra
function parsearAislamientosTxt(text) {
    const lines = text.split(/\r?\n/);
    const result = {}; // solicitud -> array de aislamientos

    let currentSolicitud = null;
    let lastAislamiento = null;

    const normalize = (s) => {
        if (!s) return '';
        const digits = String(s).replace(/\D/g, '');
        // eliminar ceros a la izquierda
        return digits.replace(/^0+/, '') || digits;
    };

    for (let i = 0; i < lines.length; i++) {
        const raw = lines[i];
        if (!raw) continue;
        const line = raw.trim();
        if (!line) continue;

        // Buscar primer número largo en la línea
        const m = line.match(/(\d{5,10})/);
        if (m) {
            const num = m[1];
            const norm = normalize(num);

            // Si el número empieza por '3' -> aislamiento ligado a la última solicitud
            if (/^3/.test(norm) && currentSolicitud) {
                // descripcion: el resto de la línea tras el número
                const descripcion = line.replace(num, '').replace(/^[-\s|]*/, '').trim();
                // buscar estados en la siguiente línea si está en mayúsculas
                let estados = '';
                if (i + 1 < lines.length) {
                    const nxt = lines[i + 1].trim();
                    if (/^[A-ZÑ0-9\s]{2,}$/.test(nxt)) { estados = nxt; i++; }
                }
                if (!result[currentSolicitud]) result[currentSolicitud] = [];
                const ais = { numero: norm, descripcion, estados };
                result[currentSolicitud].push(ais);
                lastAislamiento = ais;
            } else {
                // Nuevo identificador de Solicitud
                currentSolicitud = norm;
                lastAislamiento = null;
                if (!result[currentSolicitud]) result[currentSolicitud] = [];
            }
        } else {
            // Línea sin número: posible lista de estados que aplica al último aislamiento
            if (/^[A-ZÑ0-9\s]{2,}$/.test(line) && lastAislamiento) {
                lastAislamiento.estados = (lastAislamiento.estados ? lastAislamiento.estados + ' ' : '') + line;
            }
        }
    }

    return result;
}

// Asignar aislamientos a los trabajos en memoria buscando coincidencias por número de Solicitud
function asignarAislamientosATrabajos() {
    if (trabajos.length === 0) return;

    const normalize = (s) => {
        if (!s) return '';
        const digits = String(s).replace(/\D/g, '');
        return digits.replace(/^0+/, '') || digits;
    };

    trabajos.forEach(trabajo => {
        const solRaw = String(trabajo['Solicitud'] || '').trim();
        const sol = normalize(solRaw);

        let matches = [];
        if (aislamientosPorSolicitud.has(sol)) matches = aislamientosPorSolicitud.get(sol);
        else {
            // intentar buscar claves tocadas (con/ sin ceros)
            for (const [k, arr] of aislamientosPorSolicitud.entries()) {
                if (normalize(k) === sol) { matches = arr; break; }
            }
        }

        // Filtrar solo aislamientos que empiecen por '3' — por seguridad
        matches = (matches || []).filter(a => String(a.numero || '').startsWith('3'));

        trabajo.aislamientos = matches;
    });
}

// Manejar inicio de arrastre (desde el listado)
function handleDragStart(e) {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', e.target.dataset.indice);
    e.dataTransfer.setData('text/fecha-origen', ''); // Sin fecha de origen (viene del listado)
    e.target.classList.add('dragging');
}

// Manejar inicio de arrastre (desde el calendario)
function handleDragStartCalendario(e) {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', e.target.dataset.indice);
    e.dataTransfer.setData('text/fecha-origen', e.target.dataset.fechaOrigen);
    e.target.classList.add('dragging');
}

// Manejar fin de arrastre
function handleDragEnd(e) {
    e.target.classList.remove('dragging');
    // Remover todas las clases drag-over de todos los elementos del calendario
    const elementosConDragOver = document.querySelectorAll('.drag-over');
    elementosConDragOver.forEach(elemento => {
        elemento.classList.remove('drag-over');
    });
}

// Manejar drag over
function handleDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    // Remover drag-over de otros días del calendario antes de añadirlo al actual
    // Solo si es un día del calendario (tiene data-fecha)
    if (e.currentTarget.dataset.fecha) {
        const otrosDias = document.querySelectorAll('.dia-calendario.drag-over');
        otrosDias.forEach(dia => {
            if (dia !== e.currentTarget) {
                dia.classList.remove('drag-over');
            }
        });
    }
    e.currentTarget.classList.add('drag-over');
}

// Manejar drag leave
function handleDragLeave(e) {
    // Verificar si realmente salimos del elemento
    // relatedTarget puede ser null o puede ser un elemento fuera del currentTarget
    const relatedTarget = e.relatedTarget;
    
    // Si relatedTarget es null, definitivamente salimos del elemento
    if (!relatedTarget) {
        e.currentTarget.classList.remove('drag-over');
        return;
    }
    
    // Si relatedTarget no está dentro del currentTarget, salimos del elemento
    if (!e.currentTarget.contains(relatedTarget)) {
        e.currentTarget.classList.remove('drag-over');
    }
    // Si relatedTarget está dentro del currentTarget, no hacemos nada
    // (estamos moviendo el mouse dentro del mismo elemento)
}

// Manejar drop
function handleDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');
    
    const indiceTrabajo = parseInt(e.dataTransfer.getData('text/plain'));
    const fechaOrigen = e.dataTransfer.getData('text/fecha-origen');
    const fechaDestino = e.currentTarget.dataset.fecha;
    
    if (!fechaDestino) return; // No es un día válido del mes
    
    // Si viene de otra fecha del calendario, eliminar de la fecha de origen
    if (fechaOrigen && fechaOrigen !== fechaDestino) {
        const trabajosFechaOrigen = trabajosConFechas.get(fechaOrigen);
        if (trabajosFechaOrigen) {
            const indice = trabajosFechaOrigen.indexOf(indiceTrabajo);
            if (indice > -1) {
                trabajosFechaOrigen.splice(indice, 1);
                trabajosConFechas.set(fechaOrigen, trabajosFechaOrigen);
                
                // Actualizar visualización del día de origen
                actualizarDiaCalendario(fechaOrigen);
            }
        }
    }
    
    // Obtener o crear array de trabajos para la fecha destino
    if (!trabajosConFechas.has(fechaDestino)) {
        trabajosConFechas.set(fechaDestino, []);
    }
    
    const trabajosFechaDestino = trabajosConFechas.get(fechaDestino);
    
    // Añadir trabajo si no está ya asignado a esta fecha
    if (!trabajosFechaDestino.includes(indiceTrabajo)) {
        trabajosFechaDestino.push(indiceTrabajo);
        trabajosConFechas.set(fechaDestino, trabajosFechaDestino);
        
        // Marcar trabajo como asignado (si viene del listado)
        if (!fechaOrigen) {
            trabajosAsignados.add(indiceTrabajo);
        }
        
        // Marcar trabajo como modificado (si cambió de fecha o se asignó por primera vez)
        const valorOriginal = valoresOriginalesValidoDe.get(indiceTrabajo) || '';
        const fechaActual = obtenerFechaTrabajo(indiceTrabajo);
        // Comparar normalizando ambos valores (eliminar espacios, ordenar fechas si hay múltiples)
        const valorOriginalNormalizado = valorOriginal.toString().trim();
        const fechaActualNormalizada = fechaActual.trim();
        if (fechaActualNormalizada !== valorOriginalNormalizado) {
            trabajosModificados.add(indiceTrabajo);
        } else {
            // Si vuelve al valor original, quitar de modificados
            trabajosModificados.delete(indiceTrabajo);
        }
        
        // Actualizar visualización del calendario
        const trabajosDia = e.currentTarget.querySelector('.trabajos-dia');
        mostrarTrabajosEnDia(trabajosDia, fechaDestino);
        
        // Actualizar listado de trabajos (solo si viene del listado)
        if (!fechaOrigen) {
            mostrarTrabajos();
        }
        
        // (Gantt eliminado)
        
        // Actualizar estadísticas
        actualizarEstadisticasTrabajos();
    }
}

// Obtener la fecha asignada a un trabajo (puede ser múltiple)
function obtenerFechaTrabajo(indiceTrabajo) {
    const fechas = [];
    for (const [fecha, indices] of trabajosConFechas.entries()) {
        if (indices.includes(indiceTrabajo)) {
            fechas.push(fecha);
        }
    }
    return fechas.join(', ');
}

// Actualizar visualización de un día específico del calendario
function actualizarDiaCalendario(fechaStr) {
    // Buscar el día en el calendario
    const diaElement = document.querySelector(`[data-fecha="${fechaStr}"]`);
    if (diaElement) {
        const trabajosDia = diaElement.querySelector('.trabajos-dia');
        if (trabajosDia) {
            mostrarTrabajosEnDia(trabajosDia, fechaStr);
        }
    }
}

// Función auxiliar para obtener datos completos (para Exportar y para Subir a Nube)
function obtenerDatosCompletos() {
    if (trabajos.length === 0) {
        return null;
    }
    
    // Crear array de datos para exportar
    const datosExportar = [];
    
    // Añadir encabezados (columnas originales + nuevas columnas)
    const headers = COLUMNAS_ESPERADAS.slice();
    headers.push('Actualizada fecha');
    headers.push('Estado permiso');
    headers.push('Requiere Descargo');
    datosExportar.push(headers);
    
    // Procesar cada trabajo
    trabajos.forEach((trabajo, indice) => {
        const fila = [];
        
        // Añadir todos los campos originales en el orden esperado
        COLUMNAS_ESPERADAS.forEach((columna, colIndex) => {
            let valor = trabajo[columna] || '';
            
            // Normalizar fechas a formato DD/MM/YYYY para exportación
            if (columna === 'Válido de' || columna === 'Validez a' || columna === 'Fecha de creación') {
                // Primero normalizar a YYYY-MM-DD, luego convertir a DD/MM/YYYY
                const fechaNorm = normalizarFecha(valor);
                if (fechaNorm) {
                    const [ano, mes, dia] = fechaNorm.split('-');
                    valor = `${dia}/${mes}/${ano}`;
                }
            }
            
            // Si es la columna "Válido de", actualizar con la fecha asignada
            if (columna === 'Válido de') {
                const fechaAsignada = obtenerFechaTrabajo(indice);
                if (fechaAsignada) {
                    // fechaAsignada viene en formato YYYY-MM-DD, convertir a DD/MM/YYYY
                    const partes = fechaAsignada.split('-');
                    if (partes.length === 3) {
                        valor = `${partes[2]}/${partes[1]}/${partes[0]}`;
                    } else {
                        valor = fechaAsignada;
                    }
                }
            }
            
            // Si es la columna "Hora inicio validez", usar la hora modificada si existe
            if (columna === 'Hora inicio validez') {
                if (horasTrabajos.has(indice)) {
                    valor = horasTrabajos.get(indice);
                }
                // Mantener valor original, sin forzar 07:00
            }
            
            // Si es la columna "Validez a", usar la fecha modificada si existe
            if (columna === 'Validez a') {
                if (fechasFinTrabajos.has(indice)) {
                    const fechaFin = fechasFinTrabajos.get(indice);
                    // Convertir de YYYY-MM-DD a DD/MM/YYYY
                    const partes = fechaFin.split('-');
                    if (partes.length === 3) {
                        valor = `${partes[2]}/${partes[1]}/${partes[0]}`;
                    } else {
                        valor = fechaFin;
                    }
                }
            }
            
            fila.push(valor);
        });
        
        // Añadir campo "Actualizada fecha" (Sí/No)
        const actualizadaFecha = trabajosModificados.has(indice) ? 'Sí' : 'No';
        fila.push(actualizadaFecha);
        
        // Añadir campo "Estado permiso"
        const estadoPermiso = estadosPermisos.get(indice) || 'PENDIENTE';
        fila.push(estadoPermiso);
        
        // Añadir campo "Requiere Descargo" (Sí/No) basado en Utilización = YU1
        const requiereDescargo = trabajo.requiereDescargo === true ? 'Sí' : 'No';
        fila.push(requiereDescargo);

        // Añadir columna con aislamientos concatenados (si existen)
        const solicitudClave = String(trabajo['Solicitud'] || '').trim();
        const aislamientosArr = aislamientosPorSolicitud.get(solicitudClave) || [];
        const aislamientosStr = aislamientosArr.map(a => `${a.numero}: ${a.descripcion} [${a.estados}]`).join(' | ');
        fila.push(aislamientosStr);

        datosExportar.push(fila);
    });
    
    return datosExportar;
}

// Exportar a Excel
function exportarExcel() {
    try {
        const datosExportar = obtenerDatosCompletos();
        if (!datosExportar) {
            alert('No hay trabajos para exportar');
            return;
        }

        // Crear workbook
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet(datosExportar);
        
        // Ajustar ancho de columnas
        const colWidths = COLUMNAS_ESPERADAS.map(() => ({ wch: 15 }));
        colWidths.push({ wch: 15 }); // Para la columna "Actualizada fecha"
        colWidths.push({ wch: 15 }); // Para la columna "Estado permiso"
        colWidths.push({ wch: 18 }); // Para la columna "Requiere Descargo"
        colWidths.push({ wch: 40 }); // Para la columna "Aislamientos"
        ws['!cols'] = colWidths;
        
        XLSX.utils.book_append_sheet(wb, ws, 'Trabajos con Fechas');
        
        // Generar nombre de archivo con timestamp
        const fecha = new Date();
        const fechaStr = fecha.toISOString().split('T')[0];
        const nombreArchivo = `Trabajos_Con_Fechas_${fechaStr}.xlsx`;
        
        // Descargar archivo
        XLSX.writeFile(wb, nombreArchivo);
        
        alert('Archivo exportado exitosamente');
        
    } catch (error) {
        console.error('Error al exportar:', error);
        alert('Error al exportar el archivo: ' + error.message);
    }
}

// Subir datos a Supabase
async function subirDatosSupabase() {
    if (!supabaseClient) { 
        alert('Supabase no configurado correctamente. Verifique las credenciales en el código.'); 
        return; 
    }
    
    const password = prompt("Ingrese clave de acceso para subir datos:");
    if (password !== "uf183530") {
        alert("Clave incorrecta. Acceso denegado.");
        return;
    }

    // Preferir subir la carga cruda si está disponible (preserva filas con Solicitud que empiezan por '4')
    let datos = null;
    if (ultimoJsonData) {
        datos = ultimoJsonData;
    } else {
        datos = obtenerDatosCompletos();
    }
    if (!datos) { 
        alert('No hay datos para subir'); 
        return; 
    }

    try {
        // Mostrar indicador de carga
        const btnTexto = uploadSupabaseBtn.innerText;
        uploadSupabaseBtn.innerText = 'Subiendo...';
        uploadSupabaseBtn.disabled = true;

        // Preparar payload para subir. Mantener `data` como el contenido principal.
        // Si existen aislamientos, los embebemos dentro de `data` para evitar depender
        // de una columna separada `aislamientos` en la tabla de Supabase.
        let payload;
        if (aislamientosPorSolicitud && aislamientosPorSolicitud.size > 0) {
            // Convertir map a objeto simple
            const aisObj = {};
            aislamientosPorSolicitud.forEach((arr, key) => { aisObj[key] = arr; });
            // Nuevo formato: data -> { rows: <array de filas>, aislamientos: <obj> }
            payload = { data: { rows: datos, aislamientos: aisObj } };
        } else {
            payload = { data: datos };
        }

        const { error } = await supabaseClient
            .from('backup_excel')
            .insert([
                payload
            ]);
            
        if (error) throw error;
        alert('✅ Datos subidos correctamente a la nube.');
    } catch (error) {
        console.error('Error subiendo a Supabase:', error);
        alert('❌ Error al subir: ' + error.message);
    } finally {
        uploadSupabaseBtn.innerText = btnTexto;
        uploadSupabaseBtn.disabled = false;
    }
}

// Leer datos de Supabase
async function leerDatosSupabase(param) {
    const isAutoLoad = param === true;

    if (!supabaseClient) { 
        if (!isAutoLoad) alert('Supabase no configurado correctamente.');
        return; 
    }

    let btnTexto = '';
    if (readSupabaseBtn) {
        btnTexto = readSupabaseBtn.innerText;
        readSupabaseBtn.innerText = 'Cargando...';
        readSupabaseBtn.disabled = true;
    }

    try {
        // Obtener el último registro ordenado por fecha de creación (descendiente)
        const { data, error } = await supabaseClient
            .from('backup_excel')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(1);
            
        if (error) throw error;
        
        if (!data || data.length === 0) {
            if (!isAutoLoad) alert('No se encontraron registros guardados en la nube.');
            return;
        }

        const record = data[0];
        // Normalizar formato de `data`: puede ser un array (rows) o un objeto con {rows, aislamientos}
        let jsonData = record.data;
        // Compatibilidad: si `data` es un objeto con `rows`, extraer rows
        if (jsonData && typeof jsonData === 'object' && !Array.isArray(jsonData) && jsonData.rows) {
            // Cargar aislamientos embebidos dentro de data
            if (jsonData.aislamientos) {
                aislamientosPorSolicitud.clear();
                Object.keys(jsonData.aislamientos).forEach(k => {
                    aislamientosPorSolicitud.set(k, jsonData.aislamientos[k]);
                });
            }
            jsonData = jsonData.rows;
        }

        // Compatibilidad con el formato anterior: aislamientos como columna separada en el registro
        if (record.aislamientos && (!aislamientosPorSolicitud || aislamientosPorSolicitud.size === 0)) {
            aislamientosPorSolicitud.clear();
            Object.keys(record.aislamientos).forEach(k => {
                aislamientosPorSolicitud.set(k, record.aislamientos[k]);
            });
        }
        console.log("Datos recibidos de Supabase:", jsonData);

        // Mostrar fecha de los datos
        if (infoDatosNube) {
            const fechaData = new Date(record.created_at).toLocaleString();
            infoDatosNube.innerHTML = `☁️ Datos del: <strong>${fechaData}</strong>`;
            infoDatosNube.style.display = 'inline-block';
        }
        
        if (!Array.isArray(jsonData) || jsonData.length < 2) {
            if (!isAutoLoad) alert('Los datos descargados no tienen el formato correcto.');
            return;
        }

        // Validar headers (fila 0)
        const headers = jsonData[0];
        if (!validarColumnas(headers)) {
            if (!isAutoLoad) alert('Las columnas de los datos guardados no coinciden con la versión actual.');
            return;
        }

        // Procesar datos (Reutilizamos la lógica de carga de archivo)
        procesarDatos(jsonData);
        // Si cargamos aislamientos desde el registro, asignarlos a los trabajos
        asignarAislamientosATrabajos();
        
        // Distribuir trabajos en calendario
        distribuirTrabajos();
        
        // Actualizar visualizaciones (Gantt eliminado)
        actualizarEstadisticasTrabajos();
        
        // Habilitar botón de exportar local
        exportBtn.disabled = false;

        if (!isAutoLoad) alert('✅ Datos cargados exitosamente desde la nube.');

    } catch (error) {
        console.error('Error leyendo de Supabase:', error);
        if (!isAutoLoad) alert('❌ Error al leer de la nube: ' + error.message);
    } finally {
        if (readSupabaseBtn && btnTexto) {
            readSupabaseBtn.innerText = btnTexto;
            readSupabaseBtn.disabled = false;
        }
    }
}

// Gantt removed: función eliminará el código Gantt. Si se necesita volver a añadir, restaurar desde control de versiones.


// Cargar automáticamente datos de la nube al iniciar
document.addEventListener('DOMContentLoaded', () => {
    if (supabaseClient) {
        console.log('Iniciando carga automática desde la nube...');
        leerDatosSupabase(true);
    }
});


// ==================== FUNCIONES PESTAÑA LISTADO ====================

// Generar el listado de trabajos
function generarListado() {
    if (!listadoContainer) return;
    
    if (trabajos.length === 0) {
        listadoContainer.innerHTML = '<p class="empty-message">Carga un archivo Excel para ver el listado de trabajos</p>';
        return;
    }
    
    // Obtener fechas del filtro del listado
    const fechaInicioListado = listadoFechaInicio ? listadoFechaInicio.value : fechaInicio.value;
    const fechaFinListado = listadoFechaFin ? listadoFechaFin.value : fechaFin.value;
    
    // Mapeo de tipos a nombres de departamento
    const DEPARTAMENTO_LABELS = {
        'MTO_ELECTRICO': 'Mto. Eléctrico',
        'MTO_MECANICO': 'Mto. Mecánico',
        'GE': 'GE',
        'MTO_IC': 'Mto. I&C',
        'OTROS': 'Otros'
    };
    
    // Filtrar trabajos asignados al calendario que estén en el rango de fechas y cumplan filtro de tipo
    let trabajosFiltrados = [];
    
    trabajosConFechas.forEach((indices, fecha) => {
        // Filtrar por rango de fechas del listado
        if (fecha < fechaInicioListado || fecha > fechaFinListado) return;
        
        indices.forEach(indice => {
            const trabajo = trabajos[indice];
            if (!trabajo) return;
            
            // Aplicar filtro de tipo de mantenimiento
            if (!filtroTipos.has('TODOS') && !filtroTipos.has(trabajo.tipoMantenimiento)) {
                return;
            }
            
            // Obtener hora directamente (usar ?? para no perder 0:00:00)
            const horaRaw = horasTrabajos.has(indice) ? horasTrabajos.get(indice) : trabajo['Hora inicio validez'];
            const hora = normalizarHora(horaRaw);
            
            trabajosFiltrados.push({
                indice: indice,
                fecha: fecha,
                hora: hora,
                trabajo: trabajo
            });
        });
    });
    
    // Ordenar por fecha y luego por hora
    trabajosFiltrados.sort((a, b) => {
        // Primero por fecha
        if (a.fecha < b.fecha) return -1;
        if (a.fecha > b.fecha) return 1;
        // Luego por hora
        if (a.hora < b.hora) return -1;
        if (a.hora > b.hora) return 1;
        return 0;
    });
    
    if (trabajosFiltrados.length === 0) {
        listadoContainer.innerHTML = '<p class="empty-message">No hay trabajos en el rango de fechas seleccionado</p>';
        return;
    }
    
    // Agrupar por fecha
    const trabajosPorFecha = new Map();
    trabajosFiltrados.forEach(item => {
        if (!trabajosPorFecha.has(item.fecha)) {
            trabajosPorFecha.set(item.fecha, []);
        }
        trabajosPorFecha.get(item.fecha).push(item);
    });
    
    // Generar HTML
    let html = '';
    
    // Nombres de días y meses en español
    const diasSemana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    
    trabajosPorFecha.forEach((items, fecha) => {
        // Crear separador de fecha
        const [year, month, day] = fecha.split('-').map(Number);
        const fechaObj = new Date(year, month - 1, day);
        const diaSemana = diasSemana[fechaObj.getDay()];
        const nombreMes = meses[fechaObj.getMonth()];
        
        html += `<div class="fecha-separator">${diaSemana} ${day} de ${nombreMes} ${year}</div>`;
        
        // Crear tabla para los trabajos de este día
        html += '<table class="listado-table">';
        html += '<thead><tr>';
        html += '<th style="width: 60px;">Hora</th>';
        html += '<th style="width: 150px;">Departamento</th>';
        html += '<th style="width: 100px;">Orden</th>';
        html += '<th style="width: 100px;">Solicitud</th>';
        html += '<th style="width: 120px;">CyMP</th>';
        html += '<th>Texto breve</th>';
        html += '<th style="width: 400px;">Aislamientos</th>';
        html += '<th style="width: 80px; text-align: center;">Descargo</th>';
        html += '<th style="width: 80px; text-align: center;">Estado</th>';
        html += '</tr></thead>';
        html += '<tbody>';
        
        items.forEach(item => {
            const trabajo = item.trabajo;
            const indice = item.indice;
            
            // Obtener datos
            const hora = item.hora;
            const tipoMto = trabajo.tipoMantenimiento || 'OTROS';
            const departamentoLabel = DEPARTAMENTO_LABELS[tipoMto] || 'Otros';
            const claseTipo = trabajo.claseTipo || 'tipo-otros';
            const orden = trabajo['Orden'] || '';
            const solicitud = trabajo['Solicitud'] || '';
            let textoBreve = trabajo['Texto breve'] || '';
            //textoBreve = textoBreve.replace(/^HGPIe:\s*/i, '');
            
            // Estado del permiso
            const estadoPermiso = estadosPermisos.get(indice) || 'PENDIENTE';
            let claseEstado = 'pendiente';
            let iconoEstado = '⏳';
            if (estadoPermiso === 'AUTORIZADO') {
                claseEstado = 'autorizado';
                iconoEstado = '✓';
            } else if (estadoPermiso === 'APROBADO') {
                claseEstado = 'aprobado';
                iconoEstado = '🟧';
            }
            
            // Icono de descargo (aislamiento)
            const requiereDescargo = trabajo.requiereDescargo === true;
            const iconoDescargo = requiereDescargo ? '<span class="descargo-badge" title="Requiere acciones de aislamiento">🔒</span>' : '';
            
            html += '<tr>';
            html += `<td>${hora}</td>`;
            html += `<td><span class="departamento-badge ${claseTipo}">${departamentoLabel}</span></td>`;
            // Calcular CyMP para este trabajo
            const cympArrRow = calcularCyMPParaTrabajo(indice);
            const cympRow = (cympArrRow && cympArrRow.length > 0) ? cympArrRow.join(', ') : '';
            html += `<td>${orden}</td>`;
            html += `<td>${solicitud}</td>`;
            html += `<td>${cympRow}</td>`;
            html += `<td>${textoBreve}</td>`;
            // Mostrar aislamientos asociados a la solicitud
            const solicitudKey = (trabajo['Solicitud'] || '').toString().trim();
            const aislamientos = aislamientosPorSolicitud.get(solicitudKey) || [];
            let aislamientosHtml = '';
            if (aislamientos.length === 0) {
                aislamientosHtml = '<span class="aislamiento-vacio">—</span>';
            } else {
                aislamientosHtml = aislamientos.map(a => `<div><b>${a.numero}</b>: ${a.descripcion} <br><small>${a.estados}</small></div>`).join('<hr style="border:none;border-top:1px solid #eee;margin:4px 0;">');
            }
            html += `<td>${aislamientosHtml}</td>`;
            html += `<td style="text-align: center;">${iconoDescargo}</td>`;
            html += `<td style="text-align: center;"><span class="estado-check ${claseEstado}">${iconoEstado}</span></td>`;
            html += '</tr>';
        });
        
        html += '</tbody></table>';
    });
    
    listadoContainer.innerHTML = html;
}

// Imprimir el listado
function imprimirListado() {
    // Asegurarse de que la pestaña listado esté activa antes de imprimir
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    const listadoTabBtn = document.querySelector('.tab-button[data-tab="listado"]');
    const listadoTab = document.getElementById('listadoTab');
    
    if (listadoTabBtn) listadoTabBtn.classList.add('active');
    if (listadoTab) listadoTab.classList.add('active');
    
    // Generar el listado actualizado
    generarListado();
    
    // Pequeño delay para asegurar que el DOM se actualice
    setTimeout(() => {
        window.print();
    }, 100);
}
